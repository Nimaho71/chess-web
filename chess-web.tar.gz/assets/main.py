"""
main.py — Chess web demo (Pygbag/WASM)
Human (white) vs AI (black). R to reset, U to undo your last move.
"""
import asyncio
import pygame as p
import ChessEngine
import SmartMoveFinder
from Parameters import Parameters

WIDTH = HEIGHT = 512
DIMENSION = 8
SQ_size = HEIGHT // DIMENSION
MAX_FPS = 15
IMAGES = {}


def Load_Images():
    pieces = ["wp", "wR", "wN", "wQ", "wK", "wB", "bp", "bR", "bN", "bQ", "bK", "bB"]
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(
            p.image.load("images/" + piece + ".png"), (SQ_size, SQ_size)
        )


async def main():
    p.init()
    screen = p.display.set_mode((WIDTH, HEIGHT))
    clock = p.time.Clock()
    screen.fill(p.Color("white"))
    gs = ChessEngine.GameState()
    valid_moves = gs.get_valid_moves()
    move_made = False
    animate = False
    control_animate = True
    Load_Images()
    running = True
    sq_selected = ()
    player_click = []
    game_over = False
    player_one = True   # Human plays white
    player_two = False  # AI plays black

    while running:
        is_human_turn = (gs.white_to_move and player_one) or (
            not gs.white_to_move and player_two
        )

        for e in p.event.get():
            if e.type == p.QUIT:
                running = False

            elif e.type == p.MOUSEBUTTONDOWN:
                if not game_over and is_human_turn:
                    location = p.mouse.get_pos()
                    columb = location[0] // SQ_size
                    row = location[1] // SQ_size
                    if sq_selected == (row, columb):
                        sq_selected = ()       # deselect on same-square click
                        player_click = []
                    else:
                        sq_selected = (row, columb)
                        player_click.append(sq_selected)
                    if len(player_click) == 2:
                        move = ChessEngine.Move(player_click[0], player_click[1], gs.board)
                        for i in range(len(valid_moves)):
                            if move == valid_moves[i]:
                                gs.make_move(valid_moves[i])
                                move_made = True
                                if control_animate:
                                    animate = True
                                sq_selected = ()
                                player_click = []
                        if not move_made:
                            player_click = [sq_selected]

            elif e.type == p.KEYDOWN:
                if e.key == p.K_u and len(gs.move_log) > 0:
                    # Undo the last move pair (yours + AI's) to get back to your turn
                    gs.undo_move()
                    gs.checkmate = False
                    gs.stalemate = False
                    gs.draw_by_repetition = False
                    game_over = False
                    # If it's still the AI's turn after one undo, undo once more
                    if len(gs.move_log) > 0 and not ((gs.white_to_move and player_one) or (not gs.white_to_move and player_two)):
                        gs.undo_move()
                    valid_moves = gs.get_valid_moves()
                    sq_selected = ()
                    player_click = []
                    move_made = False
                    animate = False

                if e.key == p.K_r:
                    gs = ChessEngine.GameState()
                    valid_moves = gs.get_valid_moves()
                    sq_selected = ()
                    player_click = []
                    move_made = False
                    animate = False
                    game_over = False

        # AI move
        if not game_over and not is_human_turn:
            drawGameState(screen, gs, valid_moves, sq_selected)
            draw_text(screen, "Thinking...")
            p.display.flip()
            AI_move = SmartMoveFinder.find_best_move(gs, valid_moves, Parameters(), time_limit=1)
            if AI_move is None:
                AI_move = SmartMoveFinder.find_random_move(valid_moves)
            gs.make_move(AI_move)
            move_made = True
            if control_animate:
                animate = True

        if move_made:
            if animate:
                animate_move(gs.move_log[-1], screen, gs.board, clock)
            valid_moves = gs.get_valid_moves()
            move_made = False
            animate = False

        drawGameState(screen, gs, valid_moves, sq_selected)

        if gs.checkmate:
            game_over = True
            draw_text(screen, "Black wins by checkmate" if gs.white_to_move else "White wins by checkmate")
        elif gs.stalemate:
            game_over = True
            draw_text(screen, "Stalemate")
        elif gs.draw_by_repetition:
            game_over = True
            draw_text(screen, "Draw by repetition")

        clock.tick(MAX_FPS)
        p.display.flip()
        await asyncio.sleep(0)  # yield to browser each frame


def highlight_squeres(screen, gs, valid_moves, sq_selected):
    if sq_selected != ():
        r, c = sq_selected
        if gs.board[r][c][0] == ("w" if gs.white_to_move else "b"):
            s = p.Surface((SQ_size, SQ_size))
            s.set_alpha(100)
            s.fill(p.Color("blue"))
            screen.blit(s, (c * SQ_size, r * SQ_size))
            s.fill(p.Color("yellow"))
            for move in valid_moves:
                if move.start_row == r and move.start_columb == c:
                    screen.blit(s, (move.end_columb * SQ_size, move.end_row * SQ_size))
    if len(gs.move_log) != 0:
        last_move = gs.move_log[-1]
        s = p.Surface((SQ_size, SQ_size))
        s.set_alpha(100)
        s.fill(p.Color("light green"))
        screen.blit(s, (last_move.start_columb * SQ_size, last_move.start_row * SQ_size))
        screen.blit(s, (last_move.end_columb * SQ_size, last_move.end_row * SQ_size))


def drawGameState(screen, gs, valid_moves, sq_selected):
    drawBoard(screen)
    highlight_squeres(screen, gs, valid_moves, sq_selected)
    drawPieces(screen, gs.board)


def drawBoard(screen):
    global colors
    colors = [p.Color("white"), p.Color("dark gray")]
    for row in range(DIMENSION):
        for columb in range(DIMENSION):
            color = colors[(row + columb) % 2]
            p.draw.rect(screen, color, p.Rect(columb * SQ_size, row * SQ_size, SQ_size, SQ_size))


def drawPieces(screen, board):
    for row in range(DIMENSION):
        for columb in range(DIMENSION):
            piece = board[row][columb]
            if piece != "--":
                screen.blit(IMAGES[piece], p.Rect(columb * SQ_size, row * SQ_size, SQ_size, SQ_size))


def animate_move(move, screen, board, clock):
    global colors
    dR = move.end_row - move.start_row
    dC = move.end_columb - move.start_columb
    frames_per_squere = 10
    frame_count = (abs(dR) + abs(dC)) * frames_per_squere
    for frame in range(frame_count + 1):
        r = move.start_row + dR * frame / frame_count
        c = move.start_columb + dC * frame / frame_count
        drawBoard(screen)
        drawPieces(screen, board)
        color = colors[(move.end_row + move.end_columb) % 2]
        end_squere = p.Rect(move.end_columb * SQ_size, move.end_row * SQ_size, SQ_size, SQ_size)
        p.draw.rect(screen, color, end_squere)
        if move.piece_captured != "--":
            screen.blit(IMAGES[move.piece_captured], end_squere)
        screen.blit(IMAGES[move.piece_moved], p.Rect(c * SQ_size, r * SQ_size, SQ_size, SQ_size))
        p.display.flip()
        clock.tick(60)


def draw_text(screen, text):
    font = p.font.SysFont("Helvitca", 32, True, False)
    text_object = font.render(text, 0, p.Color("gray"))
    text_location = p.Rect(0, 0, WIDTH, HEIGHT).move(
        WIDTH / 2 - text_object.get_width() / 2,
        HEIGHT / 2 - text_object.get_height() / 2,
    )
    screen.blit(text_object, text_location)
    text_object = font.render(text, 0, p.Color("black"))
    screen.blit(text_object, text_location.move(2, 2))


asyncio.run(main())
