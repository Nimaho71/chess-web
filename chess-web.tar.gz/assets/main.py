"""
main.py — Chess web demo (Pygbag/WASM)
Config supplied by HTML UI: window.CHESS_P1, window.CHESS_P2, window.CHESS_READY
Python signals readiness via window.CHESS_ENGINE_READY
"""
import asyncio
import pygame as p
import ChessEngine
import SmartMoveFinder
from Parameters import Parameters

WIDTH = HEIGHT = 512
DIMENSION = 8
SQ_size = HEIGHT // DIMENSION
MAX_FPS = 15
IMAGES = {}


def Load_Images():
    pieces = ["wp","wR","wN","wQ","wK","wB","bp","bR","bN","bQ","bK","bB"]
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(
            p.image.load("images/" + piece + ".png"), (SQ_size, SQ_size))


def _win():
    """Return JS window or None (works both in browser and local dev)."""
    try:
        import platform
        return platform.window if hasattr(platform, "window") else None
    except Exception:
        return None


async def main():
    p.init()
    screen = p.display.set_mode((WIDTH, HEIGHT))
    clock  = p.time.Clock()
    Load_Images()

    # Tell the HTML overlay that the Python engine is ready
    w = _win()
    if w:
        try:
            w.CHESS_ENGINE_READY = True
        except Exception:
            pass

    # Wait for the HTML UI to provide game config
    player_one, player_two = True, False   # sensible fallback
    if w:
        while True:
            try:
                if str(w.CHESS_READY) == "1":
                    player_one = str(w.CHESS_P1) == "1"
                    player_two = str(w.CHESS_P2) == "1"
                    break
            except Exception:
                pass
            screen.fill((14, 13, 11))
            p.display.flip()
            await asyncio.sleep(0.1)

    # ── GAME LOOP ──────────────────────────────────────────────────────────
    gs           = ChessEngine.GameState()
    valid_moves  = gs.get_valid_moves()
    move_made    = False
    animate      = False
    ctrl_anim    = True
    sq_selected  = ()
    player_click = []
    game_over    = False

    while True:
        is_human = (gs.white_to_move and player_one) or (
                   not gs.white_to_move and player_two)

        for e in p.event.get():
            if e.type == p.QUIT:
                return

            elif e.type == p.MOUSEBUTTONDOWN:
                if not game_over and is_human:
                    col = p.mouse.get_pos()[0] // SQ_size
                    row = p.mouse.get_pos()[1] // SQ_size
                    if sq_selected == (row, col):
                        sq_selected = (); player_click = []
                    else:
                        sq_selected = (row, col)
                        player_click.append(sq_selected)
                    if len(player_click) == 2:
                        move = ChessEngine.Move(player_click[0], player_click[1], gs.board)
                        for i in range(len(valid_moves)):
                            if move == valid_moves[i]:
                                gs.make_move(valid_moves[i])
                                move_made = True
                                if ctrl_anim: animate = True
                                sq_selected = (); player_click = []
                        if not move_made:
                            player_click = [sq_selected]

            elif e.type == p.KEYDOWN:
                if e.key == p.K_a:
                    ctrl_anim = not ctrl_anim
                if e.key == p.K_u and len(gs.move_log) > 0:
                    gs.undo_move()
                    gs.checkmate = gs.stalemate = gs.draw_by_repetition = False
                    game_over = False
                    if len(gs.move_log) > 0 and not (
                        (gs.white_to_move and player_one) or
                        (not gs.white_to_move and player_two)):
                        gs.undo_move()
                    valid_moves  = gs.get_valid_moves()
                    sq_selected  = (); player_click = []
                    move_made = animate = False
                if e.key == p.K_r:
                    try:
                        w2 = _win()
                        if w2: w2.location.reload()
                    except Exception:
                        pass

        # AI move
        if not game_over and not is_human:
            drawGameState(screen, gs, valid_moves, sq_selected)
            draw_text(screen, "Thinking...")
            p.display.flip()
            AI_move = SmartMoveFinder.find_best_move(
                gs, valid_moves, Parameters(), time_limit=1)
            if AI_move is None:
                AI_move = SmartMoveFinder.find_random_move(valid_moves)
            gs.make_move(AI_move)
            move_made = True
            if ctrl_anim: animate = True

        if move_made:
            if animate:
                animate_move(gs.move_log[-1], screen, gs.board, clock)
            valid_moves = gs.get_valid_moves()
            move_made = animate = False

        drawGameState(screen, gs, valid_moves, sq_selected)

        if gs.checkmate:
            game_over = True
            draw_text(screen,
                "Black wins by checkmate" if gs.white_to_move
                else "White wins by checkmate")
        elif gs.stalemate:
            game_over = True; draw_text(screen, "Stalemate")
        elif gs.draw_by_repetition:
            game_over = True; draw_text(screen, "Draw by repetition")

        clock.tick(MAX_FPS)
        p.display.flip()
        await asyncio.sleep(0)


# ── HELPERS ────────────────────────────────────────────────────────────────

def highlight_squeres(screen, gs, valid_moves, sq_selected):
    if sq_selected != ():
        r, c = sq_selected
        if gs.board[r][c][0] == ("w" if gs.white_to_move else "b"):
            s = p.Surface((SQ_size, SQ_size)); s.set_alpha(100)
            s.fill(p.Color("blue"))
            screen.blit(s, (c * SQ_size, r * SQ_size))
            s.fill(p.Color("yellow"))
            for move in valid_moves:
                if move.start_row == r and move.start_columb == c:
                    screen.blit(s, (move.end_columb * SQ_size, move.end_row * SQ_size))
    if len(gs.move_log):
        last = gs.move_log[-1]
        s = p.Surface((SQ_size, SQ_size)); s.set_alpha(100)
        s.fill(p.Color("light green"))
        screen.blit(s, (last.start_columb * SQ_size, last.start_row * SQ_size))
        screen.blit(s, (last.end_columb   * SQ_size, last.end_row   * SQ_size))


def drawGameState(screen, gs, valid_moves, sq_selected):
    drawBoard(screen)
    highlight_squeres(screen, gs, valid_moves, sq_selected)
    drawPieces(screen, gs.board)


def drawBoard(screen):
    global colors
    colors = [p.Color("white"), p.Color("dark gray")]
    for row in range(DIMENSION):
        for col in range(DIMENSION):
            p.draw.rect(screen, colors[(row+col)%2],
                        p.Rect(col*SQ_size, row*SQ_size, SQ_size, SQ_size))


def drawPieces(screen, board):
    for row in range(DIMENSION):
        for col in range(DIMENSION):
            piece = board[row][col]
            if piece != "--":
                screen.blit(IMAGES[piece],
                            p.Rect(col*SQ_size, row*SQ_size, SQ_size, SQ_size))


def animate_move(move, screen, board, clock):
    global colors
    dR = move.end_row - move.start_row
    dC = move.end_columb - move.start_columb
    frames = (abs(dR)+abs(dC)) * 10
    for f in range(frames+1):
        r = move.start_row    + dR * f/frames
        c = move.start_columb + dC * f/frames
        drawBoard(screen); drawPieces(screen, board)
        color = colors[(move.end_row+move.end_columb)%2]
        end_sq = p.Rect(move.end_columb*SQ_size, move.end_row*SQ_size, SQ_size, SQ_size)
        p.draw.rect(screen, color, end_sq)
        if move.piece_captured != "--":
            screen.blit(IMAGES[move.piece_captured], end_sq)
        screen.blit(IMAGES[move.piece_moved],
                    p.Rect(c*SQ_size, r*SQ_size, SQ_size, SQ_size))
        p.display.flip(); clock.tick(60)


def draw_text(screen, text):
    font = p.font.SysFont("Helvetica", 32, True, False)
    obj  = font.render(text, 0, p.Color("gray"))
    loc  = p.Rect(0,0,WIDTH,HEIGHT).move(
        WIDTH//2 - obj.get_width()//2, HEIGHT//2 - obj.get_height()//2)
    screen.blit(obj, loc)
    screen.blit(font.render(text, 0, p.Color("black")), loc.move(2,2))


asyncio.run(main())
