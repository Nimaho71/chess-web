"""
main.py — Chess web demo (Pygbag/WASM)
Config from HTML UI: window.CHESS_P1 / CHESS_P2 / CHESS_READY (strings "1"/"0")
R key sets window.CHESS_RESET="1" → JS shows mode screen → Python re-waits for config
"""
import asyncio
import pygame as p
import ChessEngine
import SmartMoveFinder
from Parameters import Parameters

WIDTH = HEIGHT = 512
DIMENSION = 8
SQ_size   = HEIGHT // DIMENSION
MAX_FPS   = 15
IMAGES    = {}


def Load_Images():
    for piece in ["wp","wR","wN","wQ","wK","wB","bp","bR","bN","bQ","bK","bB"]:
        IMAGES[piece] = p.transform.scale(
            p.image.load("images/" + piece + ".png"), (SQ_size, SQ_size))


async def promotion_picker(screen, gs, color):
    """Draw a 4-piece overlay; wait for click; return chosen piece letter Q/R/B/N."""
    pieces = ["Q", "R", "B", "N"]
    total_w = SQ_size * 4
    x0 = (WIDTH - total_w) // 2
    y0 = (HEIGHT - SQ_size) // 2

    font = p.font.SysFont("Helvetica", 14, False, False)
    label = font.render("Choose promotion", True, p.Color("white"))

    while True:
        drawGameState(screen, gs, [], ())
        # dark backdrop
        bg = p.Surface((total_w + 8, SQ_size + 34), p.SRCALPHA)
        bg.fill((20, 18, 15, 230))
        screen.blit(bg, (x0 - 4, y0 - 30))
        screen.blit(label, (WIDTH // 2 - label.get_width() // 2, y0 - 22))

        mx, my = p.mouse.get_pos()
        for i, pp in enumerate(pieces):
            x = x0 + i * SQ_size
            hover = x <= mx < x + SQ_size and y0 <= my < y0 + SQ_size
            border_col = p.Color(201, 168, 76) if hover else p.Color(80, 70, 60)
            p.draw.rect(screen, border_col, (x, y0, SQ_size, SQ_size), 2)
            screen.blit(IMAGES[color + pp], (x, y0))

        p.display.flip()

        for e in p.event.get():
            if e.type == p.QUIT:
                return "Q"
            if e.type == p.MOUSEBUTTONDOWN:
                mx, my = p.mouse.get_pos()
                if y0 <= my < y0 + SQ_size:
                    idx = (mx - x0) // SQ_size
                    if 0 <= idx < 4:
                        return pieces[idx]
        await asyncio.sleep(0)


def _win():
    try:
        import platform
        return platform.window if hasattr(platform, "window") else None
    except Exception:
        return None


async def main():
    p.init()
    screen = p.display.set_mode((WIDTH, HEIGHT))
    clock  = p.time.Clock()
    Load_Images()

    w = _win()
    if w:
        try:
            w.CHESS_ENGINE_READY = True
        except Exception:
            pass

    # Outer loop — re-runs after R (mode-screen return without page reload)
    want_restart = True
    while want_restart:
        want_restart = False
        params = Parameters()  # created once per game session

        # ── Wait for HTML UI to provide game config ────────────────────
        player_one, player_two = True, False      # fallback
        if w:
            while True:
                try:
                    if str(w.CHESS_READY) == "1":
                        player_one = str(w.CHESS_P1) == "1"
                        player_two = str(w.CHESS_P2) == "1"
                        break
                except Exception:
                    pass
                screen.fill((14, 13, 11))
                p.display.flip()
                await asyncio.sleep(0.1)

        # ── Game loop ──────────────────────────────────────────────────
        gs           = ChessEngine.GameState()
        valid_moves  = gs.get_valid_moves()
        move_made    = False
        animate      = False
        ctrl_anim    = True
        sq_selected  = ()
        player_click = []
        game_over    = False
        game_running = True

        while game_running:
            is_human = (gs.white_to_move and player_one) or (
                       not gs.white_to_move and player_two)

            for e in p.event.get():
                if e.type == p.QUIT:
                    return

                elif e.type == p.MOUSEBUTTONDOWN:
                    if not game_over and is_human:
                        col = p.mouse.get_pos()[0] // SQ_size
                        row = p.mouse.get_pos()[1] // SQ_size
                        if sq_selected == (row, col):
                            sq_selected = (); player_click = []
                        else:
                            sq_selected = (row, col)
                            player_click.append(sq_selected)
                        if len(player_click) == 2:
                            # Match by position (not move_id) so promotion squares work
                            sr, sc = player_click[0]; er, ec = player_click[1]
                            matched = None
                            for vm in valid_moves:
                                if (vm.start_row == sr and vm.start_columb == sc
                                        and vm.end_row == er and vm.end_columb == ec):
                                    if vm.is_pawn_promotion:
                                        color = "w" if gs.white_to_move else "b"
                                        chosen = await promotion_picker(screen, gs, color)
                                        # find the valid move with the chosen piece
                                        matched = next(
                                            (v for v in valid_moves
                                             if v.start_row == sr and v.start_columb == sc
                                             and v.end_row == er and v.end_columb == ec
                                             and v.promotion_piece == chosen),
                                            vm)  # fallback to first match
                                    else:
                                        matched = vm
                                    break
                            if matched:
                                gs.make_move(matched)
                                move_made = True
                                if ctrl_anim: animate = True
                                sq_selected = (); player_click = []
                            else:
                                player_click = [sq_selected]

                elif e.type == p.KEYDOWN:
                    if e.key == p.K_a:
                        ctrl_anim = not ctrl_anim

                    elif e.key == p.K_u and len(gs.move_log) > 0:
                        gs.undo_move()
                        gs.checkmate = gs.stalemate = gs.draw_by_repetition = False
                        game_over = False
                        if len(gs.move_log) > 0 and not (
                            (gs.white_to_move and player_one) or
                            (not gs.white_to_move and player_two)):
                            gs.undo_move()
                        valid_moves  = gs.get_valid_moves()
                        sq_selected  = (); player_click = []
                        move_made = animate = False

                    elif e.key == p.K_r:
                        # Signal JS to show mode screen; loop back to wait
                        try:
                            if w:
                                w.CHESS_READY = "0"
                                w.CHESS_RESET = "1"
                        except Exception:
                            pass
                        want_restart = True
                        game_running = False

            if not game_running:
                break

            # AI move
            if not game_over and not is_human:
                drawGameState(screen, gs, valid_moves, sq_selected)
                draw_text(screen, "Thinking...")
                p.display.flip()
                AI_move = SmartMoveFinder.find_best_move(
                    gs, valid_moves, params, time_limit=1)
                if AI_move is None:
                    AI_move = SmartMoveFinder.find_random_move(valid_moves)
                gs.make_move(AI_move)
                move_made = True
                if ctrl_anim: animate = True

            if move_made:
                if animate:
                    animate_move(gs.move_log[-1], screen, gs.board, clock)
                valid_moves = gs.get_valid_moves()
                move_made = animate = False

            drawGameState(screen, gs, valid_moves, sq_selected)

            if gs.checkmate:
                game_over = True
                draw_text(screen,
                    "Black wins by checkmate" if gs.white_to_move
                    else "White wins by checkmate")
            elif gs.stalemate:
                game_over = True; draw_text(screen, "Stalemate")
            elif gs.draw_by_repetition:
                game_over = True; draw_text(screen, "Draw by repetition")

            clock.tick(MAX_FPS)
            p.display.flip()
            await asyncio.sleep(0)


# ── Helpers ────────────────────────────────────────────────────────────────

def highlight_squeres(screen, gs, valid_moves, sq_selected):
    if sq_selected != ():
        r, c = sq_selected
        if gs.board[r][c][0] == ("w" if gs.white_to_move else "b"):
            s = p.Surface((SQ_size, SQ_size)); s.set_alpha(100)
            s.fill(p.Color("blue"))
            screen.blit(s, (c*SQ_size, r*SQ_size))
            s.fill(p.Color("yellow"))
            for move in valid_moves:
                if move.start_row == r and move.start_columb == c:
                    screen.blit(s, (move.end_columb*SQ_size, move.end_row*SQ_size))
    if gs.move_log:
        last = gs.move_log[-1]
        s = p.Surface((SQ_size, SQ_size)); s.set_alpha(100)
        s.fill(p.Color("light green"))
        screen.blit(s, (last.start_columb*SQ_size, last.start_row*SQ_size))
        screen.blit(s, (last.end_columb*SQ_size,   last.end_row*SQ_size))

def drawGameState(screen, gs, valid_moves, sq_selected):
    drawBoard(screen)
    highlight_squeres(screen, gs, valid_moves, sq_selected)
    drawPieces(screen, gs.board)

def drawBoard(screen):
    global colors
    colors = [p.Color("white"), p.Color("dark gray")]
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            p.draw.rect(screen, colors[(r+c)%2],
                        p.Rect(c*SQ_size, r*SQ_size, SQ_size, SQ_size))

def drawPieces(screen, board):
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            piece = board[r][c]
            if piece != "--":
                screen.blit(IMAGES[piece],
                            p.Rect(c*SQ_size, r*SQ_size, SQ_size, SQ_size))

def animate_move(move, screen, board, clock):
    global colors
    dR = move.end_row - move.start_row
    dC = move.end_columb - move.start_columb
    frames = (abs(dR)+abs(dC))*10
    for f in range(frames+1):
        r = move.start_row    + dR*f/frames
        c = move.start_columb + dC*f/frames
        drawBoard(screen); drawPieces(screen, board)
        color  = colors[(move.end_row+move.end_columb)%2]
        end_sq = p.Rect(move.end_columb*SQ_size, move.end_row*SQ_size, SQ_size, SQ_size)
        p.draw.rect(screen, color, end_sq)
        if move.piece_captured != "--":
            screen.blit(IMAGES[move.piece_captured], end_sq)
        screen.blit(IMAGES[move.piece_moved],
                    p.Rect(c*SQ_size, r*SQ_size, SQ_size, SQ_size))
        p.display.flip(); clock.tick(60)

def draw_text(screen, text):
    font = p.font.SysFont("Helvetica", 32, True, False)
    obj  = font.render(text, 0, p.Color("gray"))
    loc  = p.Rect(0,0,WIDTH,HEIGHT).move(
        WIDTH//2 - obj.get_width()//2, HEIGHT//2 - obj.get_height()//2)
    screen.blit(obj, loc)
    screen.blit(font.render(text, 0, p.Color("black")), loc.move(2,2))


asyncio.run(main())
