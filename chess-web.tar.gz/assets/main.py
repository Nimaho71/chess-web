"""
main.py — Chess web demo (Pygbag/WASM)
Mode select → game.  R = mode screen · U = undo (skips AI reply) · A = animation toggle
"""
import asyncio
import pygame as p
import ChessEngine
import SmartMoveFinder
from Parameters import Parameters

WIDTH = HEIGHT = 512
DIMENSION = 8
SQ_size = HEIGHT // DIMENSION
MAX_FPS = 15
IMAGES = {}

# ── palette shared by the two lobby screens ────────────────────────────────
_DARK   = (30,  30,  30)
_BTN_N  = (60,  60,  60)
_BTN_H  = (95,  95,  95)
_FG     = (220, 220, 220)
_DIM    = (130, 130, 130)
_BORDER = (80,  190, 80)


def Load_Images():
    pieces = ["wp", "wR", "wN", "wQ", "wK", "wB",
              "bp", "bR", "bN", "bQ", "bK", "bB"]
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(
            p.image.load("images/" + piece + ".png"), (SQ_size, SQ_size)
        )


# ── lobby screens ──────────────────────────────────────────────────────────

async def select_mode(screen, clock):
    """Mode-select lobby. Returns (player_one, player_two)."""
    large = p.font.Font(None, 72)
    mid   = p.font.Font(None, 38)
    small = p.font.Font(None, 26)

    MODES = [
        ("Human  vs  AI",    None),           # None → triggers side picker
        ("Human  vs  Human", (True,  True)),
        ("AI  vs  AI",       (False, False)),
    ]
    BW, BH, BY0 = 268, 52, 178

    while True:
        mx, my = p.mouse.get_pos()
        screen.fill(_DARK)

        t = large.render("CHESS", True, _FG)
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 52))

        s = small.render("Select game mode", True, _DIM)
        screen.blit(s, (WIDTH // 2 - s.get_width() // 2, 132))

        btns = [p.Rect(WIDTH // 2 - BW // 2, BY0 + i * 74, BW, BH)
                for i in range(3)]

        for r, (label, _) in zip(btns, MODES):
            hov = r.collidepoint(mx, my)
            p.draw.rect(screen, _BTN_H if hov else _BTN_N, r, border_radius=8)
            p.draw.rect(screen, _BORDER, r, 2, border_radius=8)
            txt = mid.render(label, True, _FG)
            screen.blit(txt, (r.centerx - txt.get_width() // 2,
                               r.centery - txt.get_height() // 2))

        hint = small.render(
            "R = mode screen  ·  U = undo  ·  A = animation toggle",
            True, (75, 75, 75)
        )
        screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, 468))

        for e in p.event.get():
            if e.type == p.QUIT:
                return True, False          # browser will close anyway
            if e.type == p.MOUSEBUTTONDOWN and e.button == 1:
                for r, (_, result) in zip(btns, MODES):
                    if r.collidepoint(e.pos):
                        if result is None:  # Human vs AI → pick side
                            picked = await _pick_side(screen, clock,
                                                      large, mid, small)
                            if picked is not None:
                                return picked
                            # None means back → fall through to redraw
                        else:
                            return result

        p.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


async def _pick_side(screen, clock, large, mid, small):
    """Side-select sub-screen. Returns (player_one, player_two), or None for back."""
    SIDES = [("White", (True, False)), ("Black", (False, True))]
    BW, BH = 168, 52

    while True:
        mx, my = p.mouse.get_pos()
        screen.fill(_DARK)

        t = large.render("CHESS", True, _FG)
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 52))

        s = mid.render("Play as:", True, _DIM)
        screen.blit(s, (WIDTH // 2 - s.get_width() // 2, 152))

        # Two side buttons, side by side
        btns = [
            p.Rect(WIDTH // 2 - BW - 14, 228, BW, BH),
            p.Rect(WIDTH // 2 + 14,       228, BW, BH),
        ]
        for r, (label, _) in zip(btns, SIDES):
            hov = r.collidepoint(mx, my)
            p.draw.rect(screen, _BTN_H if hov else _BTN_N, r, border_radius=8)
            p.draw.rect(screen, _BORDER, r, 2, border_radius=8)
            txt = mid.render(label, True, _FG)
            screen.blit(txt, (r.centerx - txt.get_width() // 2,
                               r.centery - txt.get_height() // 2))

        # Back link
        back_surf = small.render("← Back", True, _DIM)
        back_rect = p.Rect(18, 18, back_surf.get_width() + 10,
                           back_surf.get_height() + 6)
        hov_back = back_rect.collidepoint(mx, my)
        p.draw.rect(screen, _BTN_H if hov_back else _DARK,
                    back_rect, border_radius=4)
        screen.blit(back_surf, (back_rect.x + 5, back_rect.y + 3))

        for e in p.event.get():
            if e.type == p.QUIT:
                return True, False
            if e.type == p.MOUSEBUTTONDOWN and e.button == 1:
                if back_rect.collidepoint(e.pos):
                    return None             # signal: go back to mode screen
                for r, (_, result) in zip(btns, SIDES):
                    if r.collidepoint(e.pos):
                        return result

        p.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


# ── game loop ──────────────────────────────────────────────────────────────

async def main():
    p.init()
    screen = p.display.set_mode((WIDTH, HEIGHT))
    clock  = p.time.Clock()
    Load_Images()

    quit_game = False
    while not quit_game:
        player_one, player_two = await select_mode(screen, clock)

        gs = ChessEngine.GameState()
        valid_moves  = gs.get_valid_moves()
        move_made    = False
        animate      = False
        control_animate = True
        sq_selected  = ()
        player_click = []
        game_over    = False
        game_running = True

        while game_running and not quit_game:
            is_human_turn = (gs.white_to_move and player_one) or (
                not gs.white_to_move and player_two
            )

            for e in p.event.get():
                if e.type == p.QUIT:
                    quit_game = True

                elif e.type == p.MOUSEBUTTONDOWN:
                    if not game_over and is_human_turn:
                        location = p.mouse.get_pos()
                        columb = location[0] // SQ_size
                        row    = location[1] // SQ_size
                        if sq_selected == (row, columb):
                            sq_selected  = ()
                            player_click = []
                        else:
                            sq_selected = (row, columb)
                            player_click.append(sq_selected)
                        if len(player_click) == 2:
                            move = ChessEngine.Move(
                                player_click[0], player_click[1], gs.board
                            )
                            for i in range(len(valid_moves)):
                                if move == valid_moves[i]:
                                    gs.make_move(valid_moves[i])
                                    move_made = True
                                    if control_animate:
                                        animate = True
                                    sq_selected  = ()
                                    player_click = []
                            if not move_made:
                                player_click = [sq_selected]

                elif e.type == p.KEYDOWN:
                    if e.key == p.K_a:
                        control_animate = not control_animate

                    if e.key == p.K_u and len(gs.move_log) > 0:
                        gs.undo_move()
                        gs.checkmate = gs.stalemate = gs.draw_by_repetition = False
                        game_over = False
                        # Skip past the AI's reply move so it's the human's turn again
                        if len(gs.move_log) > 0 and not (
                            (gs.white_to_move and player_one)
                            or (not gs.white_to_move and player_two)
                        ):
                            gs.undo_move()
                        valid_moves  = gs.get_valid_moves()
                        sq_selected  = ()
                        player_click = []
                        move_made = animate = False

                    if e.key == p.K_r:
                        game_running = False   # return to mode screen

            # Exit before AI move if R was pressed
            if not game_running:
                break

            # AI move
            if not game_over and not is_human_turn:
                drawGameState(screen, gs, valid_moves, sq_selected)
                draw_text(screen, "Thinking...")
                p.display.flip()
                AI_move = SmartMoveFinder.find_best_move(
                    gs, valid_moves, Parameters(), time_limit=1
                )
                if AI_move is None:
                    AI_move = SmartMoveFinder.find_random_move(valid_moves)
                gs.make_move(AI_move)
                move_made = True
                if control_animate:
                    animate = True

            if move_made:
                if animate:
                    animate_move(gs.move_log[-1], screen, gs.board, clock)
                valid_moves = gs.get_valid_moves()
                move_made = animate = False

            drawGameState(screen, gs, valid_moves, sq_selected)

            if gs.checkmate:
                game_over = True
                draw_text(
                    screen,
                    "Black wins by checkmate"
                    if gs.white_to_move else "White wins by checkmate",
                )
            elif gs.stalemate:
                game_over = True
                draw_text(screen, "Stalemate")
            elif gs.draw_by_repetition:
                game_over = True
                draw_text(screen, "Draw by repetition")

            clock.tick(MAX_FPS)
            p.display.flip()
            await asyncio.sleep(0)   # yield to browser each frame


# ── helpers ────────────────────────────────────────────────────────────────

def highlight_squeres(screen, gs, valid_moves, sq_selected):
    if sq_selected != ():
        r, c = sq_selected
        if gs.board[r][c][0] == ("w" if gs.white_to_move else "b"):
            s = p.Surface((SQ_size, SQ_size))
            s.set_alpha(100)
            s.fill(p.Color("blue"))
            screen.blit(s, (c * SQ_size, r * SQ_size))
            s.fill(p.Color("yellow"))
            for move in valid_moves:
                if move.start_row == r and move.start_columb == c:
                    screen.blit(s, (move.end_columb * SQ_size, move.end_row * SQ_size))
    if len(gs.move_log) != 0:
        last = gs.move_log[-1]
        s = p.Surface((SQ_size, SQ_size))
        s.set_alpha(100)
        s.fill(p.Color("light green"))
        screen.blit(s, (last.start_columb * SQ_size, last.start_row * SQ_size))
        screen.blit(s, (last.end_columb   * SQ_size, last.end_row   * SQ_size))


def drawGameState(screen, gs, valid_moves, sq_selected):
    drawBoard(screen)
    highlight_squeres(screen, gs, valid_moves, sq_selected)
    drawPieces(screen, gs.board)


def drawBoard(screen):
    global colors
    colors = [p.Color("white"), p.Color("dark gray")]
    for row in range(DIMENSION):
        for columb in range(DIMENSION):
            color = colors[(row + columb) % 2]
            p.draw.rect(screen, color,
                        p.Rect(columb * SQ_size, row * SQ_size, SQ_size, SQ_size))


def drawPieces(screen, board):
    for row in range(DIMENSION):
        for columb in range(DIMENSION):
            piece = board[row][columb]
            if piece != "--":
                screen.blit(IMAGES[piece],
                            p.Rect(columb * SQ_size, row * SQ_size, SQ_size, SQ_size))


def animate_move(move, screen, board, clock):
    global colors
    dR = move.end_row    - move.start_row
    dC = move.end_columb - move.start_columb
    frame_count = (abs(dR) + abs(dC)) * 10
    for frame in range(frame_count + 1):
        r = move.start_row    + dR * frame / frame_count
        c = move.start_columb + dC * frame / frame_count
        drawBoard(screen)
        drawPieces(screen, board)
        color = colors[(move.end_row + move.end_columb) % 2]
        end_sq = p.Rect(move.end_columb * SQ_size, move.end_row * SQ_size,
                        SQ_size, SQ_size)
        p.draw.rect(screen, color, end_sq)
        if move.piece_captured != "--":
            screen.blit(IMAGES[move.piece_captured], end_sq)
        screen.blit(IMAGES[move.piece_moved],
                    p.Rect(c * SQ_size, r * SQ_size, SQ_size, SQ_size))
        p.display.flip()
        clock.tick(60)


def draw_text(screen, text):
    font = p.font.SysFont("Helvitca", 32, True, False)
    obj  = font.render(text, 0, p.Color("gray"))
    loc  = p.Rect(0, 0, WIDTH, HEIGHT).move(
        WIDTH  // 2 - obj.get_width()  // 2,
        HEIGHT // 2 - obj.get_height() // 2,
    )
    screen.blit(obj, loc)
    screen.blit(font.render(text, 0, p.Color("black")), loc.move(2, 2))


asyncio.run(main())
