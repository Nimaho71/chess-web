# Chess Engine Improvement Checklist

Mark items with [x] when complete. Add initials + date in parens.

---

## 🔴 Correctness Bugs (wrong results, not just slow)

- [x] **Castling rights: wrong branch in `update_castling_rights`**
  The `elif move.end_row == 0:` branch under `piece_captured == "wR"` incorrectly
  modifies `bks`/`bqs`. Fixed by separating into its own `elif piece_captured == "bR":` block.
  Impact: silently strips black castling rights in rare edge positions. *(fixed)*

- [x] **50-move rule: `break` stops counting too early**
  Loop iterates oldest→newest; `break` on first pawn/capture means only moves
  before the first reset are counted — not consecutive moves since the last reset.
  Also: was checking 50 half-moves (25 full moves) instead of 100 half-moves (50 full moves).
  Fix: replace `break` with counter reset; check last 100 half-moves.
  Impact: rule almost never fires correctly. *(fixed)*

- [x] **Promotion: always forces Queen; no player choice**
  `make_move` hardcodes `piece_moved[0] + "Q"`. Player and AI have no say.
  Fix: add `promotion_piece` field to `Move`, generate 4 moves per promotion square
  in `get_pawn_moves`, async picker UI for human, AI searches all 4 options naturally.
  Impact: underpromotion impossible; player can't choose. *(fixed)*

- [x] **`move_id` collision on underpromotion**
  `start_row*1000 + col*100 + end_row*10 + end_col` — two promotions to same square
  produce identical IDs. Fixed by encoding promotion piece into ID.
  Impact: move equality broken for underpromotions. *(fixed)*

- [ ] **Repetition detection: compares move sequences, not positions**
  Current check: last 4 moves == 4 moves before that. Real threefold repetition
  requires the same *board position* (including castling rights + en passant) to appear
  3 times. Correct fix: Zobrist hashing — assign a random 64-bit number to each
  (piece, square) combination, XOR them together for the board hash, store hashes in
  a Counter, declare draw when any hash reaches count 3.
  WASM compatible: yes (pure Python).
  Impact: currently misses most real repetitions; may false-positive on symmetrical play.
  Strength impact: LOW (draw detection only) | Correctness impact: HIGH

---

## 🟠 Performance (search speed / depth)

- [ ] **No transposition table** ← biggest single win
  Same position reached by different move orders is re-searched from scratch every time.
  Fix: dict keyed by Zobrist hash storing (depth, score, flag, best_move).
  On each node: lookup hash → if depth >= remaining depth, return stored score.
  WASM compatible: yes.
  Estimated impact: 5–20× more nodes in same time → 2–3 extra depth levels. CRITICAL.

- [ ] **`score_board` scans all 64 squares at every leaf**
  Called hundreds of thousands of times per second at depth 4+.
  Fix: incremental evaluation — maintain `white_score`/`black_score` floats updated
  only for the 2 squares that change on make/undo. Evaluation becomes O(1) per node.
  WASM compatible: yes.
  Estimated impact: 30–50% more nodes/sec. HIGH.

- [ ] **`deepcopy` in `undo_move` for Castle_rights**
  `copy.deepcopy(self.castle_rights_log[-1])` on every undo. deepcopy uses
  pickle-like introspection; it's 50–100× slower than a simple constructor call.
  Fix: store castle rights as a 4-tuple `(wks, wqs, bks, bqs)` in the log;
  unpack on undo: `r = log[-1]; rights.wks, rights.wqs, ... = r`.
  WASM compatible: yes.
  Estimated impact: ~5–10% faster undo-heavy paths. MEDIUM.

- [ ] **`Parameters()` re-instantiated on every AI call**
  Creates and copies 24 PST tables (8×8 each) on every move. 
  Fix: create one `params = Parameters()` at startup and pass it in.
  1-line change in main.py.
  WASM compatible: yes.
  Estimated impact: tiny, but free. LOW.

- [ ] **`time.time()` called at every search node**
  At 100k+ nodes/sec, syscall overhead is measurable.
  Fix: only check time every 2048 nodes: `if counter & 2047 == 0: check_time()`.
  WASM compatible: yes.
  Estimated impact: ~2–5% faster search. LOW.

- [ ] **`get_valid_moves()` called inside quiescence for captures**
  Full legal move gen (pins/checks/castling) runs just to filter captures.
  Fix: write a dedicated `get_capture_moves()` that only scans attacked squares
  and skips pin checking (captures in check are filtered separately).
  WASM compatible: yes.
  Estimated impact: faster quiescence search. MEDIUM.

- [ ] **Quiescence search depth hardcoded at 16**
  At iterative depth 1, 16 extra plies of captures is overkill and slows early
  iterations of iterative deepening.
  Fix: scale with main depth: `max(6, iterative_depth + 4)`.
  WASM compatible: yes.
  Estimated impact: faster shallow searches, better use of time budget. MEDIUM.

---

## 🟡 Search Features (stronger play)

- [ ] **Aspiration windows**
  After completing depth N with score S, search depth N+1 with window [S-50, S+50].
  If score falls outside, re-search with full window. Usually faster than full-window.
  WASM compatible: yes.
  Strength impact: MEDIUM. Easy to add.

- [ ] **Null move pruning**
  At depth ≥ 3 and not in check: make a null move (skip turn), search at depth-3.
  If score ≥ beta, the position is too good — prune. Skip zugzwang positions
  (pawn-only endgames).
  WASM compatible: yes.
  Strength impact: HIGH. Halves search time in most middlegame positions.

- [ ] **Futility pruning**
  At depth 1–2: if static eval + margin < alpha, skip the move (it can't improve alpha).
  WASM compatible: yes.
  Strength impact: MEDIUM. Reduces nodes at shallow depth.

- [ ] **Better Late Move Reduction (LMR)**
  Currently reduces by exactly 1. Standard formula: reduce by `int(log(depth) * log(move_index) / 2)`.
  Don't reduce captures, promotions, or checks.
  WASM compatible: yes.
  Strength impact: MEDIUM–HIGH at deeper searches.

- [ ] **Draw by insufficient material**
  K vs K, K+N vs K, K+B vs K, K+N+N vs K — these are drawn but the engine
  searches forever. Detect in `get_valid_moves` or `score_board`.
  WASM compatible: yes.
  Strength impact: LOW (correctness only, rare positions).

---

## 🔵 Board Representation (requires larger refactor)

- [ ] **2D list of strings → numpy int8 array**
  Current: `board[r][c]` returns a 2-char Python string. Piece comparison creates
  temp substrings on every node. A numpy `int8` array with piece constants
  (0=empty, 1=wP, 2=wN, … 12=bK) would enable vectorized PST evaluation.
  `board = np.zeros(64, dtype=np.int8)` indexed as `board[r*8+c]`.
  WASM compatible: yes (numpy available in pygbag CDN).
  Strength impact: HIGH (enables fast eval). Refactor effort: HIGH.

- [ ] **PST lookup via string-keyed dict → list indexed by piece int**
  If board uses int piece IDs, `params.pst[piece_id][sq]` replaces the string dict
  lookup. Combine with numpy for vectorized eval.
  WASM compatible: yes.
  Strength impact: MEDIUM (tied to board representation change above).

---

## 🟣 Code Quality

- [ ] **Dead functions: remove or move to archive**
  `find_gready_move`, `find_move_min_max`, `find_move_nega_max`, `score_material`
  in SmartMoveFinder.py — never called. Remove or move to a `legacy.py`.

- [ ] **Dead imports**
  `from operator import index`, `from types import NoneType` in SmartMoveFinder.py.
  `import random` in Parameters.py. Remove all three.

- [ ] **Global search state → `SearchState` dataclass**
  `next_move`, `counter`, `killer_moves`, `history_moves`, `pv_table`,
  `endgame_weight`, `start_time`, `end_time`, `iterative_depth` are all module-level
  globals. This breaks AI vs AI mode (second call corrupts first call's state).
  Fix: bundle into a `@dataclass class SearchState` and pass it through.

- [ ] **`board_to_fen` is an empty stub**
  `def board_to_fen(self): pass` in ChessEngine.py. Either implement or remove.
  Useful for debugging and for connecting to external engines later.

- [ ] **Typo: `columb` / `squere` throughout**
  ~40 occurrences. Best done in one pass: rename all to `col`/`sq` in both
  ChessEngine.py and SmartMoveFinder.py and main.py simultaneously.
  Do this as a standalone PR — touches many lines.

- [ ] **`Castle_rights` → namedtuple**
  Currently a class with 4 booleans. Replace with:
  `Castle_rights = namedtuple("Castle_rights", ["wks", "wqs", "bks", "bqs"])`
  Enables unpacking and eliminates deepcopy (namedtuples are immutable).
  Ties into the deepcopy fix above.

- [ ] **`Parameters` parameter name shadows class**
  `def find_best_move(gs, valid_moves, Parameters: Parameters, ...)` — the parameter
  name `Parameters` shadows the class import. Rename parameter to `params`.

---

## ⚪ Security

- [ ] **Add Content Security Policy to vercel.json**
  Add `Content-Security-Policy` header restricting scripts to `'self'` and the
  Pygbag CDN (`pygame-web.github.io`). Low urgency for a chess demo but good
  practice for a portfolio project.

---

## Impact Summary Table

| Item | Strength ∆ | Effort | WASM? |
|---|---|---|---|
| Transposition table | ★★★★★ | Medium | ✅ |
| Null move pruning | ★★★★☆ | Low | ✅ |
| Incremental eval | ★★★☆☆ | Medium | ✅ |
| Better LMR | ★★★☆☆ | Low | ✅ |
| numpy board repr | ★★★☆☆ | High | ✅ |
| Aspiration windows | ★★☆☆☆ | Low | ✅ |
| Futility pruning | ★★☆☆☆ | Low | ✅ |
| Quiescence depth fix | ★★☆☆☆ | Trivial | ✅ |
| Repetition (Zobrist) | correctness | Medium | ✅ |
| deepcopy fix | ★☆☆☆☆ | Trivial | ✅ |
| Parameters singleton | ★☆☆☆☆ | Trivial | ✅ |
| time.time() frequency | ★☆☆☆☆ | Trivial | ✅ |
| Numba @njit | N/A | N/A | ❌ no |
| Real threading | N/A | N/A | ❌ no |
