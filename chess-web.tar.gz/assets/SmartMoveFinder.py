import math
import random
import time
import copy
from operator import index
from types import NoneType

from ChessEngine import GameState, Move
from Parameters import Parameters  # static chess parameters for the AI

"""
Global variables
"""

CHECKMATE = float("inf")
STALEMATE = 0
DRAW_BY_REPETITION = 0
DEPTH = 4

# Transposition table: zobrist_hash -> (depth, score, flag, best_move)
TT_EXACT = 0
TT_LOWER = 1   # fail-high, true value >= score
TT_UPPER = 2   # fail-low,  true value <= score
transposition_table = {}

"""
Different chess AI
"""
NULL_MOVE_REDUCTION = 2   # depth reduction for null move search
FUTILITY_MARGIN_DEPTH_1 = 100   # ~1 pawn — margin at 1 ply from a leaf
FUTILITY_MARGIN_DEPTH_2 = 300   # ~1 minor piece — margin at 2 plies from a leaf

def _make_null_move(gs):
    """Switch sides without moving — for null move pruning. Updates Zobrist."""
    from ChessEngine import _ZOB_SIDE, _ZOB_EP
    gs.white_to_move = not gs.white_to_move
    gs.hash_log.append(gs.zobrist_hash)
    h = gs.zobrist_hash ^ _ZOB_SIDE
    if gs.en_passant_possible:
        h ^= _ZOB_EP[gs.en_passant_possible[1]]
    gs._saved_ep = gs.en_passant_possible
    gs.en_passant_possible = ()
    gs.zobrist_hash = h
    gs.position_history[h] = gs.position_history.get(h, 0) + 1

def _undo_null_move(gs):
    """Reverse null move."""
    gs.position_history[gs.zobrist_hash] = gs.position_history.get(gs.zobrist_hash, 1) - 1
    gs.zobrist_hash = gs.hash_log.pop()
    gs.en_passant_possible = gs._saved_ep
    gs.white_to_move = not gs.white_to_move

# plays random move
def find_random_move(valid_moves):
    return valid_moves[random.randint(0, len(valid_moves)-1)]

# min max without recursion
def find_gready_move(gs, valid_moves):
    turn_multiplier = 1 if gs.white_to_move else -1  # black wants to mimimaze, white wants to maximize
    white_to_actualy_move = True if gs.white_to_move else False
    opponent_min_max_score = CHECKMATE
    best_player_move = None
    random.shuffle(valid_moves)
    for player_move in valid_moves:
        gs.make_move(player_move)
        opponents_moves = gs.get_valid_moves()
        opponent_max_score = -CHECKMATE
        if gs.checkmate:
            opponent_max_score = -CHECKMATE
        elif gs.stalemate:
            opponent_max_score = STALEMATE
        else:
            for opponents_move in opponents_moves:
                gs.make_move(opponents_move)
                gs.get_valid_moves
                if gs.checkmate:
                    score = CHECKMATE
                elif gs.stalemate:
                    score = STALEMATE
                else:
                    score = -turn_multiplier * score_material(gs.board, player_move, opponents_moves, white_to_actualy_move)
                if score > opponent_max_score:
                    opponent_max_score = score
                gs.undo_move()
        if opponent_max_score < opponent_min_max_score:
            opponent_min_max_score = opponent_max_score
            best_player_move = player_move
        gs.undo_move()
    print((-opponent_min_max_score if white_to_actualy_move else opponent_min_max_score)/100)
    return best_player_move


# calls wanted move-finder algorithm
def find_best_move(gs: GameState, valid_moves: list[Move], Parameters: Parameters, time_limit: int = 2, MAX_DEPTH: int = 20) -> Move | None:
    global counter, capture_counter, iterative_depth, start_time, end_time, killer_moves, history_moves, pv_table, next_move
    next_move = None
    counter = 0  # counts the number of moves searched
    capture_counter = 0  # counts the number of capture moves searched
    start_time = time.time()
    end_time = time_limit
    killer_moves = KillerMoveTable()  # initializes KillerMoveTable to clear it
    history_moves = HistoryMoveTable()  # initializes HistoryMoveTable to clear it
    pv_table = PVTable()
    transposition_table.clear()  # fresh table each move (avoids cross-move draw/history edge cases)

    iterative_depth = 1
    opening_book = OpeningBook()
    if gs.starting_fen == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1":
        possible_move = opening_book.get_next_move(gs)
        if possible_move in valid_moves:
            return possible_move

    #print(f"white opening book")
    #for key, value in opening_book.white_book.items():
        #print(f"{key}: {value},")

    #print(f"black opening book")
    #for key, value in opening_book.black_book.items():
        #print(f"{key}: {value},")

    ASPIRATION_WINDOW = 50    # centipawns
    prev_score = 0
    turn = 1 if gs.white_to_move else -1

    while iterative_depth <= MAX_DEPTH:
        if time.time() - start_time > time_limit:
            break

        # Aspiration window — narrow search around previous score
        if iterative_depth >= 3:
            alpha_asp = prev_score - ASPIRATION_WINDOW
            beta_asp  = prev_score + ASPIRATION_WINDOW
            score = find_move_nega_max_alpha_beta(gs, valid_moves, iterative_depth,
                                                  alpha_asp, beta_asp, turn, Parameters)
            # Failed high or low — re-search with full window
            if score <= alpha_asp or score >= beta_asp:
                score = find_move_nega_max_alpha_beta(gs, valid_moves, iterative_depth,
                                                      -CHECKMATE, CHECKMATE, turn, Parameters)
        else:
            score = find_move_nega_max_alpha_beta(gs, valid_moves, iterative_depth,
                                                  -CHECKMATE, CHECKMATE, turn, Parameters)

        prev_score = score

        if score == CHECKMATE:
            break
        if time.time() - start_time > time_limit:
            break

        iterative_depth += 1

    current_time = time.time()
    # print(f"Depth reached: {iterative_depth - 1}, Time taken: {current_time - start_time:.2f}s, Evaluations: {counter}, score: {score/100}")

    return next_move

# min max with recursion
def find_move_min_max(gs, valid_moves, depth, white_to_move):
    global next_move
    if depth == 0:
        depth = DEPTH
        return score_board(gs.board)

    if white_to_move:
        max_score = -CHECKMATE
        for move in valid_moves:
            gs.make_move(move)
            next_moves = gs.get_valid_moves()
            score = find_move_min_max(gs, next_moves, depth -1, False)
            if score > max_score:
                max_score = score
                if depth == DEPTH:
                    next_move = move
            gs.undo_move()
        return max_score
    else:
        min_score = CHECKMATE
        for move in valid_moves:
            gs.make_move(move)
            next_moves = gs.get_valid_moves()
            score = find_move_min_max(gs, next_moves, depth - 1, True)
            if score < min_score:
                min_score = score
                if depth == DEPTH:
                    next_move = move
            gs.undo_move()
        return min_score

def find_move_nega_max(gs, valid_moves, depth, turn_multiplier, move = None):
    global next_move

    if depth == 0:
        return turn_multiplier * evaluate(gs, move, turn_multiplier, Parameters)

    max_score = -CHECKMATE
    for move in valid_moves:
        gs.make_move(move)
        next_moves = gs.get_valid_moves()
        score = -find_move_nega_max(gs, next_moves, depth-1, -turn_multiplier, move)
        if score > max_score:
            max_score = score
            if depth == DEPTH:
                next_move = move
        gs.undo_move()
    return max_score

def find_move_nega_max_alpha_beta(gs, valid_moves, depth, alpha, beta, turn_multiplier, Parameters, move = None, ply_from_root = 0, num_extensions = 0):
    global counter, killer_moves, history_moves, pv_table, next_move  # global variables for best move and moves searched
    counter += 1

    if counter & 511 == 0 and time.time() - start_time > end_time:  # check time every 512 nodes
        return alpha

    pv_table.pv_length[ply_from_root] = ply_from_root

    if depth == 0 or gs.checkmate or gs.stalemate or gs.draw_by_repetition:
        return quiescence_search(alpha, beta, gs, quiescence_search_depth(iterative_depth), move, turn_multiplier, Parameters)

    # Transposition table probe
    tt_move = None
    tt_entry = transposition_table.get(gs.zobrist_hash)
    if tt_entry is not None:
        tt_depth, tt_score, tt_flag, tt_move = tt_entry
        if tt_depth >= depth:
            if tt_flag == TT_EXACT:
                return tt_score
            elif tt_flag == TT_LOWER and tt_score >= beta:
                return tt_score
            elif tt_flag == TT_UPPER and tt_score <= alpha:
                return tt_score

    # move ordering by heuristic function, sort best move first (TT move goes first if present)
    valid_moves.sort(key=lambda move: (move == tt_move, move_heuristic(gs, move, ply_from_root, Parameters)), reverse=True)

    # Null move pruning — skip our turn; if still >= beta the position is too good to bother
    if (depth >= 3 and not gs.in_check and ply_from_root > 0
            and len(valid_moves) > 0):
        _make_null_move(gs)
        null_moves = gs.get_valid_moves()
        null_score = -find_move_nega_max_alpha_beta(
            gs, null_moves, depth - 1 - NULL_MOVE_REDUCTION,
            -beta, -alpha, -turn_multiplier, Parameters, None,
            ply_from_root + 1, num_extensions)
        _undo_null_move(gs)
        if null_score >= beta:
            return beta

    # Futility pruning setup — a quiet move this close to a leaf can't swing the
    # score enough to matter, so estimate with a static eval + safety margin.
    # Disabled in check and near mate scores (see chessprogramming.org/Futility_Pruning).
    futility_base = None
    if depth in (1, 2) and not gs.in_check and abs(alpha) < CHECKMATE and abs(beta) < CHECKMATE:
        margin = FUTILITY_MARGIN_DEPTH_1 if depth == 1 else FUTILITY_MARGIN_DEPTH_2
        futility_base = turn_multiplier * evaluate(gs, move, Parameters) + margin

    alpha_orig = alpha        # remember original bound for TT flag classification
    best_move_node = None     # best move found at this node (for TT storage)
    max_score = -CHECKMATE
    i = 0  # move count in search
    for move in valid_moves:
        i += 1
        if (futility_base is not None and i > 1 and futility_base <= alpha
                and move.piece_captured == "--" and not move.is_pawn_promotion
                and not move.is_castle_move):  # castling's value (king safety) isn't visible in a
            continue  # shallow static eval — never prune it, or the engine stops wanting to castle
        needs_full_search = True
        gs.make_move(move)
        next_moves = gs.get_valid_moves()
        extension = calculate_extension_depth(gs.in_check, move, num_extensions)  # extend positions in checks and pawn close to queening

        if i > 1 and extension == 0 and depth >= 3 and not killer_moves.is_killer_move(move, ply_from_root):  # LMR, late move reduction reduce un interesting moves
            reduced_depth = 1
            score = -find_move_nega_max_alpha_beta(gs, next_moves, depth - 1 - reduced_depth, -(alpha+1), -alpha, -turn_multiplier, Parameters, move, ply_from_root + 1, num_extensions + extension)  # if firsts move, search it with full window
            needs_full_search = score > alpha  #  if the move is so better than previus best move it neeeds full search

        if needs_full_search:
            score = -find_move_nega_max_alpha_beta(gs, next_moves, depth - 1 + extension, -beta, -alpha, -turn_multiplier, Parameters,
                                                   move, ply_from_root + 1, num_extensions + extension)

        if score > max_score:
            max_score = score
            best_move_node = move
            if ply_from_root == 0 and time.time() - start_time < end_time:
                next_move = move

            if time.time() - start_time < end_time:
                pv_table.table[ply_from_root][ply_from_root] = move

                for next_ply in range(ply_from_root + 1, pv_table.pv_length[ply_from_root + 1]):
                    pv_table.table[ply_from_root][next_ply] = pv_table.table[ply_from_root + 1][next_ply]

                # update pv_length after copying
                pv_table.pv_length[ply_from_root] = pv_table.pv_length[ply_from_root + 1]

                # At root: set full PV line
                # if ply_from_root == 0:
                    # pv_table.full_pv_length = pv_table.pv_length[0]
                    # pv_table.full_pv_line = pv_table.table[0][:pv_table.full_pv_length]

        gs.undo_move()
        if max_score > alpha:
            alpha = max_score  # update alpha if position better then alpha
            if alpha == CHECKMATE:  # if forced checkmate is found, break
                return alpha
        if alpha >= beta:  # cut the search if position worse then alpha
            killer_moves.add_move(move, ply_from_root)  # add killer move
            history_moves.add_history_score(move, depth, ply_from_root)  # add history score to move
            transposition_table[gs.zobrist_hash] = (depth, max_score, TT_LOWER, best_move_node)
            return beta

    flag = TT_EXACT if max_score > alpha_orig else TT_UPPER
    transposition_table[gs.zobrist_hash] = (depth, max_score, flag, best_move_node)
    return alpha  # return score of position

def quiescence_search(alpha, beta, gs, quiescence_depth, move, turn_multiplier, Parameters):
    global capture_counter

    if capture_counter & 255 == 0 and time.time() - start_time > end_time:
        return alpha

    if quiescence_depth == 0 or gs.checkmate or gs.stalemate or gs.draw_by_repetition:  # check for end cases
        return turn_multiplier * evaluate(gs, move, Parameters)  # returns the evaluation of the position. line returns a
        # positive number if position is good for player to move

    evaluation = turn_multiplier * evaluate(gs, move, Parameters)
    if evaluation >= beta:
        return beta
    if alpha < evaluation:
        alpha = evaluation
        if alpha == CHECKMATE:  # if forced checkmate is found, break
            return alpha

    capture_moves = [move for move in gs.get_valid_moves() if move.piece_captured != "--" or move.is_enpassant_move]

    capture_moves.sort(key=lambda move: quiescence_heuristic(move, Parameters), reverse=True)

    for move in capture_moves:
        gs.make_move(move)
        capture_counter += 1
        evaluation = -quiescence_search(-beta, -alpha, gs, quiescence_depth-1, move, -turn_multiplier, Parameters)
        gs.undo_move()

        if evaluation >= beta:
            return beta
        if evaluation > alpha:
            alpha = evaluation
            if alpha == CHECKMATE:  # if forced checkmate is found, break
                return alpha

    return alpha



def quiescence_search_depth(iterative_depth: int) -> int:
    """
    function for determening how much depth shoud be seached in the quiescence search
    """
    return 16

def calculate_extension_depth(in_check, move, num_extensions):
    extension = 0
    if num_extensions < 16:
        if in_check or (move.piece_moved == "p" and (move.end_row == 6 or move.end_row == 1)) or move.is_pawn_promotion:
            extension = 1

    return extension

def move_heuristic(gs, move, ply_from_root, Parameters):
    global pv_table
    """
    Moves order from:
    best previus move
    mvv-lva, most valueble victem least valueble attacker, and also pawn promotion
    killer moves
    history moves
    castling
    """
  # make sure a pv line exsist in move ordering
    if move == pv_table.table[0][ply_from_root]: # check if move is best move from previus iteration.
        move_score_guess = float("inf")  # set its score to maximum to put it first in valid moves
        return move_score_guess  # return its score

    move_score_guess = 0  # all moves start with a predicted score of 0 (neutral)
    killer_bias = 50  # sort killer moves after captures, lowest capture is queen takes pawn with a score of 100

    if move.piece_captured != "--":  # If a piece is captured
        move_score_guess += 11 * Parameters.piece_score[move.piece_captured[1]] - Parameters.piece_score[move.piece_moved[1]] + 10000  # Get value from the second character, e.g., 'Q' from 'wQ'

    if move.is_enpassant_move:  # If the move is an en passant move
        move_score_guess += 10 * Parameters.piece_score['p'] + 10000  # Add value of a pawn since en passant captures a pawn

    if move.is_pawn_promotion:  # If the move is a pawn promotion
        move_score_guess += Parameters.piece_score["Q"] - Parameters.piece_score["p"] + 10000 # Promotion search after history

    if killer_moves.is_killer_move(move, ply_from_root):
        move_score_guess += killer_bias + 9000

    move_score_guess += history_moves.history_score(move) + 10

    if move.is_castle_move:  # If the move is a castle move
        move_score_guess += 1  # search after pawn promotion

    #board = copy.deepcopy(gs.board)
    #captured_piece = move.piece_captured  # captured piece
    # ally_color = move.piece_moved[0]  # ally color
    #board[move.end_row][move.end_columb] = move.piece_moved  # put moved piece to end square
    #board[move.start_row][move.start_columb] = "--"  # remove piece from start square

    # enemy_king_location = gs.black_king_location if ally_color == "w" else gs.white_king_location # enemy king location

    # if gs.squere_under_attack(enemy_king_location[0], enemy_king_location[1]):  # enemy king in check
        # move_score_guess += 20  # bonus for check move

    # if gs.squere_under_attack(move.end_row, move.end_columb):  # square you move to is under attack
        # move_score_guess -= 0.4 * Parameters.piece_score[move.piece_moved[1]]  # penalty

    #board[move.end_row][move.end_columb] = captured_piece  # put captured piece back
    #board[move.start_row][move.start_columb] = move.piece_moved  # put back piece moved

    return move_score_guess

def quiescence_heuristic(move, Parameters):
    move_score_guess = 0  # the guessed score for the quiescence move based on quiescence_heuristic parameters
    if move.piece_captured != "--":  # If a piece is captured
        move_score_guess += 10 * Parameters.piece_score[move.piece_captured[1]] - Parameters.piece_score[move.piece_moved[1]]  # Get value
        # from the second character, e.g., 'Q' from 'wQ'

    if move.is_pawn_promotion:  # If the move is a pawn promotion
        move_score_guess += 10*Parameters.piece_score['Q']  # Promote to a queen, adding its value

    if move.is_enpassant_move:  # If the move is an en passant move
        move_score_guess += 9*Parameters.piece_score['p']  # Add value of a pawn since en passant captures a pawn

    return move_score_guess

"""
a positive score good for white, a negative score good for black
"""

def evaluate(gs, move, Parameters):
    if gs.checkmate:  # check for checkmate
        return -CHECKMATE if gs.white_to_move else CHECKMATE
    elif gs.stalemate:  # check for stalemate
        return STALEMATE
    elif gs.draw_by_repetition:  # check for draw by repetition
        return DRAW_BY_REPETITION

    ally_color = "w" if gs.white_to_move else "b"  # color of pieces the side to move has

    global endgame_weight  # global endgame weight for determening in what stage the game is in, a dynamic value ranging
    # from 1 (early game) to 0 (endgame), gets set by the score_board function
    board_score = score_board(gs, Parameters)  # must run first — this sets endgame_weight
    move_bonus = score_move(move, gs.current_castling_rights, gs.white_has_castled, gs.black_has_castled, ally_color) if move is not None else 0
    total_score = board_score + move_bonus + force_king_to_corner_endgame(
        gs.white_king_location if gs.white_to_move else gs.black_king_location,
        gs.black_king_location if gs.white_to_move else gs.white_king_location, endgame_weight)  # returns total score of the position

    return total_score

def score_board(gs, Parameters):
    """
    O(1) — reads GameState's incrementally-maintained running totals instead of
    rescanning all 64 squares. Totals are kept in sync by ChessEngine's make_move/
    undo_move via GameState._apply_move_score(). `Parameters` arg kept for call-site
    stability even though gs.params (guaranteed identical, see Parameters.py) is used.
    """
    global endgame_weight

    max_material_score = 8120  # Adjust this value based on your piece score definitions
    endgame_weight = (1 - min(1, gs.material_on_board / max_material_score))
    board_score = (gs.pieces_on_board_score + (1 - endgame_weight) * gs.early_game_position_score
                   + endgame_weight * gs.end_game_position_score)

    return board_score

def score_move(move, current_castling_rights, white_has_castled, black_has_castled, ally_color):
    global endgame_weight
    move_score = 0

    # a penalty for not being able to castle
    if not current_castling_rights.wks and not white_has_castled:
        move_score -= 10
    if not current_castling_rights.wqs and not white_has_castled:
        move_score -= 10
    if not current_castling_rights.bks and not black_has_castled:
        move_score += 10
    if not current_castling_rights.bqs and not black_has_castled:
        move_score += 10

    # var has_castled after castel move = true else false, then undomove if undone move = castle move has castled = false

    if not white_has_castled and ally_color == "w":
        move_score -= (1 - endgame_weight) * 40  # penalty in early-mid game
    if not black_has_castled and ally_color == "b":
        move_score += (1 - endgame_weight) * 40

    return move_score

def force_king_to_corner_endgame(friendly_king_location, enemy_king_location, endgame_weight):
    evaluation = 0
    oppontent_king_row = enemy_king_location[0]
    oppontent_king_columb = enemy_king_location[1]


    opp_king_dst_to_center_row = max(3 - oppontent_king_row, 4 - oppontent_king_row)
    opp_king_dst_to_center_columb = max(3 - oppontent_king_columb, 4 - oppontent_king_columb)
    opp_king_dst_from_center = opp_king_dst_to_center_row + opp_king_dst_to_center_columb
    evaluation += opp_king_dst_from_center

    friendly_king_row = friendly_king_location[0]
    friendly_king_columb = friendly_king_location[1]

    dst_between_kings_row = abs(friendly_king_row-oppontent_king_row)
    dst_between_kings_columb = abs(friendly_king_columb-oppontent_king_columb)
    dst_between_kings = dst_between_kings_row + dst_between_kings_columb
    evaluation += (14 - dst_between_kings)

    return 10 * evaluation * endgame_weight



"""
score position based on pieces
"""
def score_material(board, player_move, opponents_moves, white_to_actualy_move, Parameters):
    score = 0
    for row in board:
        for square in row:
            if square[0] == "w":
                score += Parameters.piece_score[square[1]]
            elif square[0] == "b":
                score -= Parameters.piece_score[square[1]]

    if player_move.is_castle_move:
        score += 50

    return score

class KillerMoveTable:
    def __init__(self):
        self.max_depth = 20
        self.slots_per_depth = 2
        self.killer_table = [[None] * self.slots_per_depth for _ in range(self.max_depth+16)]  # max depth + max number of extensions
        self.indices = [0] * len(self.killer_table)  # Keep track of the next insertion point for each depth

    def add_move(self, move, ply_from_root):
        if move.piece_captured == "--" and not move.is_enpassant_move and move.move_id not in self.killer_table[ply_from_root]:
            index = self.indices[ply_from_root]
            self.killer_table[ply_from_root][index] = move.move_id
            # Update the circular index
            self.indices[ply_from_root] = (index + 1) % self.slots_per_depth

    def is_killer_move(self, move, ply_from_root):
        return move.move_id in self.killer_table[ply_from_root]

class HistoryMoveTable:
    def __init__(self):
        self.num_of_squares = 64
        self.num_of_unique_pieces = 12
        self.num_of_rows = 8
        self.piece_to_history_index = {
            'bp': 0, 'bR': 1, 'bN': 2, 'bB': 3, 'bQ': 4, 'bK': 5,  # Black pieces
            'wp': 6, 'wR': 7, 'wN': 8, 'wB': 9, 'wQ': 10, 'wK': 11  # White pieces
        }

        # History table: [piece_index][square_index]
        self.history_table = [[0 for _ in range(self.num_of_squares)] for _ in range(self.num_of_unique_pieces)]

    def clamp(self, value, max_value, min_value):  # clamps a number between two values
        return max(min(max_value, value), min_value)

    def add_history_score(self, move, depth, ply_from_root):
        if move.piece_captured == "--" and not move.is_enpassant_move:
            piece_type = move.piece_moved  # piece moved
            piece_index = self.piece_to_history_index[piece_type]  # index of piece in history table
            square_index = self.num_of_rows * move.end_row + move.end_columb  # index of square in history table

            self.history_table[piece_index][square_index] += (depth * depth) / (ply_from_root + 1) # add depth to the score of the move

    def history_score(self, move):
        piece_type = move.piece_moved  # piece moved
        piece_index = self.piece_to_history_index[piece_type]  # index of piece in history table
        square_index = self.num_of_rows * move.end_row + move.end_columb  # index of square in history table

        return self.history_table[piece_index][square_index]

class PVTable:
    def __init__(self):
        """
        Initializes a triangular PV table.
        :param max_depth: maximum depth of search
        """
        self.max_depth = 20+16  # max depth + max number of extensions
        self.pv_length = [None for _ in range(self.max_depth)]
        self.table = [[None for _ in range(self.max_depth)] for _ in range(self.max_depth)]
        # self.full_pv_length = 0
        # self.full_pv_line = None

    def get_pv_line(self, ply_from_root):
        """
        Returns the current principal variation line starting at a given ply.
        :param ply: Ply to start from
        :return: List of Move objects
        """

        pv_line = []
        for d in range(ply_from_root, self.max_depth):
            move = self.table[ply_from_root][d]
            if move is None:
                break
            pv_line.append(move)
        return pv_line

    def __str__(self):
        s = ""
        for ply in range(self.max_depth):
            line = self.get_pv_line(ply)
            s += f"Ply {ply}: {' '.join(str(m.get_chess_notation()) for m in line)}\n"
        return s


class OpeningBook:
    def __init__(self):
        """
        Dictionary where:
        - Key: Tuple of move strings, e.g., ("e2e4", "e7e5")
        - Value: List of next possible moves, e.g., ["g1f3", "d2d4"]
        """

        self.white_book = {(): ['d2d4', 'e2e4'],
('d2d4',): ['d7d5', 'g8f6'],
('d2d4', 'd7d5'): ['c1f4'],
('d2d4', 'd7d5', 'c1f4'): ['g8f6', 'b8c6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6'): ['e2e3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3'): ['e7e6', 'c7c5', 'c8f5'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6'): ['g1f3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3'): ['f8d6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6'): ['f4g3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3'): ['d6g3', 'e8g8'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'd6g3'): ['h2g3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8'): ['f1d3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3'): ['b8c6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6'): ['c2c3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3'): ['c8d7'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7'): ['b1d2'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7', 'b1d2'): ['d8e7'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7', 'b1d2', 'd8e7'): ['f3e5'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7', 'b1d2', 'd8e7', 'f3e5'): ['a7a6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7', 'b1d2', 'd8e7', 'f3e5', 'a7a6'): ['e1g1'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7', 'b1d2', 'd8e7', 'f3e5', 'a7a6', 'e1g1'): ['d6e5'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7', 'b1d2', 'd8e7', 'f3e5', 'a7a6', 'e1g1', 'd6e5'): ['d4e5'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'e7e6', 'g1f3', 'f8d6', 'f4g3', 'e8g8', 'f1d3', 'b8c6', 'c2c3', 'c8d7', 'b1d2', 'd8e7', 'f3e5', 'a7a6', 'e1g1', 'd6e5', 'd4e5'): ['f6e8'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5'): ['g1f3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3'): ['d8b6', 'b8c6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6'): ['b1c3'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3'): ['b6b2'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2'): ['c3b5'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5'): ['b8a6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6'): ['a1b1'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a1b1'): ['b2a2'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a1b1', 'b2a2'): ['b1a1'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a1b1', 'b2a2', 'b1a1'): ['a2b2'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a1b1', 'b2a2', 'b1a1', 'a2b2'): ['a1a6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a1b1', 'b2a2', 'b1a1', 'a2b2', 'a1a6'): ['b7a6'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a1b1', 'b2a2', 'b1a1', 'a2b2', 'a1a6', 'b7a6'): ['b5c7'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c7c5', 'g1f3', 'b8c6'): ['b1d2'],
('d2d4', 'd7d5', 'c1f4', 'g8f6', 'e2e3', 'c8f5'): ['c2c4'],
('d2d4', 'g8f6'): ['c1f4'],
('d2d4', 'g8f6', 'c1f4'): ['g7g6', 'd7d5'],
('d2d4', 'g8f6', 'c1f4', 'g7g6'): ['b1c3'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3'): ['f8g7', 'd7d5'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'f8g7'): ['e2e4'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'f8g7', 'e2e4'): ['d7d6'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'f8g7', 'e2e4', 'd7d6'): ['d1d2'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5'): ['e2e3'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3'): ['f8g7'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3', 'f8g7'): ['h2h4'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3', 'f8g7', 'h2h4'): ['e8g8'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3', 'f8g7', 'h2h4', 'e8g8'): ['h4h5'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3', 'f8g7', 'h2h4', 'e8g8', 'h4h5'): ['f6h5'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3', 'f8g7', 'h2h4', 'e8g8', 'h4h5', 'f6h5'): ['h1h5'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3', 'f8g7', 'h2h4', 'e8g8', 'h4h5', 'f6h5', 'h1h5'): ['g6h5'],
('d2d4', 'g8f6', 'c1f4', 'g7g6', 'b1c3', 'd7d5', 'e2e3', 'f8g7', 'h2h4', 'e8g8', 'h4h5', 'f6h5', 'h1h5', 'g6h5'): ['d1h5'],
('d2d4', 'd7d5', 'c1f4', 'b8c6'): ['e2e3'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3'): ['f7f6'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'f7f6'): ['g1f3', 'c2c4'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'a7a6'): ['c2c4'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'g8f6'): ['b1d2'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'c8f5'): ['c2c4'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'f7f6', 'g1f3'): ['g7g5'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'f7f6', 'g1f3', 'g7g5'): ['f4g3'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'f7f6', 'g1f3', 'g7g5', 'f4g3'): ['h7h5'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'f7f6', 'g1f3', 'g7g5', 'f4g3', 'h7h5'): ['h2h4'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'f7f6', 'g1f3', 'g7g5', 'f4g3', 'h7h5', 'h2h4'): ['g5g4'],
('d2d4', 'd7d5', 'c1f4', 'b8c6', 'e2e3', 'f7f6', 'g1f3', 'g7g5', 'f4g3', 'h7h5', 'h2h4', 'g5g4'): ['f3d2'],
('d2d4', 'g8f6', 'c1f4', 'd7d5'): ['e2e3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3'): ['c7c5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5'): ['g1f3'],
('e2e4',): ['c7c6'],
('e2e4', 'c7c6'): ['d2d4'],
('e2e4', 'c7c6', 'd2d4'): ['d7d5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5'): ['b1c3', 'e4e5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3'): ['d5e4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4'): ['c3e4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4'): ['c8f5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5'): ['e4g3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3'): ['f5g6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6'): ['h2h4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4'): ['h7h6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6'): ['f3e5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5'): ['g6h7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7'): ['f1d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3'): ['h7d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3', 'h7d3'): ['d1d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3', 'h7d3', 'd1d3'): ['b8d7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3', 'h7d3', 'd1d3', 'b8d7'): ['d3e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5'): ['c6c5', 'c8f5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5'): ['d4c5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5'): ['e7e6', 'b8c6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3'): ['f8c5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5'): ['f1d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3'): ['b8c6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6'): ['e1g1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1'): ['g8e7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1', 'g8e7'): ['a2a3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1', 'g8e7', 'a2a3'): ['a7a5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1', 'g8e7', 'a2a3', 'a7a5'): ['d1e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6'): ['f2f4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6'): ['c1e3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6', 'c1e3'): ['d5d4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6', 'c1e3', 'd5d4'): ['e3f2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6', 'c1e3', 'd5d4', 'e3f2'): ['f8c5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6', 'c1e3', 'd5d4', 'e3f2', 'f8c5'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6', 'c1e3', 'd5d4', 'e3f2', 'f8c5', 'g1f3'): ['g8e7', 'g8h6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6', 'c1e3', 'd5d4', 'e3f2', 'f8c5', 'g1f3', 'g8e7'): ['c2c3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'b8c6', 'f2f4', 'e7e6', 'c1e3', 'd5d4', 'e3f2', 'f8c5', 'g1f3', 'g8h6'): ['c2c3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6'): ['f1e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6', 'f1e2'): ['c6c5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6', 'f1e2', 'c6c5'): ['e1g1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6', 'f1e2', 'c6c5', 'e1g1'): ['b8c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3'): ['d8b6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6'): ['b1c3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3'): ['b6b2', 'c5c4', 'c5d4', 'a7a6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2'): ['c3b5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5'): ['b8a6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6'): ['a2a3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3'): ['c8f5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5'): ['d4c5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5'): ['f5c2'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2'): ['d1c1'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1'): ['b2c1'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1'): ['a1c1'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1'): ['c2f5', 'c2a4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5'): ['b5d4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4'): ['f5d7'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7'): ['c5c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6'): ['b7c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6', 'b7c6'): ['f1a6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6', 'b7c6', 'f1a6'): ['f6e4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6', 'b7c6', 'f1a6', 'f6e4'): ['a6b7'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6', 'b7c6', 'f1a6', 'f6e4', 'a6b7'): ['a8d8'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6', 'b7c6', 'f1a6', 'f6e4', 'a6b7', 'a8d8'): ['d4c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6', 'b7c6', 'f1a6', 'f6e4', 'a6b7', 'a8d8', 'd4c6'): ['d7c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2f5', 'b5d4', 'f5d7', 'c5c6', 'b7c6', 'f1a6', 'f6e4', 'a6b7', 'a8d8', 'd4c6', 'd7c6'): ['b7c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2a4'): ['c5c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2a4', 'c5c6'): ['b7c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'b6b2', 'c3b5', 'b8a6', 'a2a3', 'c8f5', 'd4c5', 'f5c2', 'd1c1', 'b2c1', 'a1c1', 'c2a4', 'c5c6', 'b7c6'): ['c1c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5c4'): ['e3e4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5c4', 'e3e4'): ['d5e4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5c4', 'e3e4', 'd5e4'): ['f3e5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5c4', 'e3e4', 'd5e4', 'f3e5'): ['b6b2'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5c4', 'e3e4', 'd5e4', 'f3e5', 'b6b2'): ['f1c4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5d4'): ['c3b5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5d4', 'c3b5'): ['b8a6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5d4', 'c3b5', 'b8a6'): ['e3d4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5d4', 'c3b5', 'b8a6', 'e3d4'): ['g7g6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5d4', 'c3b5', 'b8a6', 'e3d4', 'g7g6'): ['a2a4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5d4', 'c3b5', 'b8a6', 'e3d4', 'g7g6', 'a2a4'): ['f8g7'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'c5d4', 'c3b5', 'b8a6', 'e3d4', 'g7g6', 'a2a4', 'f8g7'): ['h2h3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6'): ['d4c5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5'): ['b6c5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5'): ['f1d3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3'): ['c8g4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4'): ['h2h3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3'): ['g4h5', 'g4f3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4h5'): ['g2g4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4h5', 'g2g4'): ['h5g6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4h5', 'g2g4', 'h5g6'): ['d3g6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4h5', 'g2g4', 'h5g6', 'd3g6'): ['h7g6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4h5', 'g2g4', 'h5g6', 'd3g6', 'h7g6'): ['g4g5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3'): ['d1f3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3', 'd1f3'): ['e7e6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3', 'd1f3', 'e7e6'): ['e1g1'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3', 'd1f3', 'e7e6', 'e1g1'): ['b8c6']}
        self.black_book = {(): ['d2d4', 'e2e4'],
('d2d4',): ['g8f6'],
('d2d4', 'g8f6'): ['c1g5', 'c2c4', 'c1f4'],
('d2d4', 'g8f6', 'c1g5'): ['e7e6'],
('d2d4', 'g8f6', 'c2c4'): ['e7e6'],
('d2d4', 'g8f6', 'c2c4', 'e7e6'): ['g1f3', 'b1c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3'): ['d7d5', 'b7b6'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3'): ['f8b4'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4'): ['d1c2', 'e2e3', 'g2g3', 'a2a3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2'): ['b7b6', 'd7d5'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6'): ['g1f3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3'): ['c8b7'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7'): ['e2e3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7', 'e2e3'): ['f6e4'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7', 'e2e3', 'f6e4'): ['f1d3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7', 'e2e3', 'f6e4', 'f1d3'): ['b4c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7', 'e2e3', 'f6e4', 'f1d3', 'b4c3'): ['b2c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7', 'e2e3', 'f6e4', 'f1d3', 'b4c3', 'b2c3'): ['f7f5'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7', 'e2e3', 'f6e4', 'f1d3', 'b4c3', 'b2c3', 'f7f5'): ['e1g1'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'b7b6', 'g1f3', 'c8b7', 'e2e3', 'f6e4', 'f1d3', 'b4c3', 'b2c3', 'f7f5', 'e1g1'): ['e8g8'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3'): ['b7b6'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6'): ['f1d3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3'): ['c8b7'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7'): ['g1f3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7', 'g1f3'): ['e8g8', 'f6e4'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7', 'g1f3', 'e8g8'): ['e1g1'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7', 'g1f3', 'e8g8', 'e1g1'): ['b4c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7', 'g1f3', 'e8g8', 'e1g1', 'b4c3'): ['b2c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7', 'g1f3', 'e8g8', 'e1g1', 'b4c3', 'b2c3'): ['f6e4'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7', 'g1f3', 'e8g8', 'e1g1', 'b4c3', 'b2c3', 'f6e4'): ['d1c2'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'e2e3', 'b7b6', 'f1d3', 'c8b7', 'g1f3', 'e8g8', 'e1g1', 'b4c3', 'b2c3', 'f6e4', 'd1c2'): ['f7f5'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'g2g3'): ['d7d5'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'g2g3', 'd7d5'): ['a2a3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'g2g3', 'd7d5', 'a2a3'): ['b4c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'g2g3', 'd7d5', 'a2a3', 'b4c3'): ['b2c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3', 'b7b6'): ['b1c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3', 'b7b6', 'b1c3'): ['f8b4'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3', 'b7b6', 'b1c3', 'f8b4'): ['a2a3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3', 'b7b6', 'b1c3', 'f8b4', 'a2a3'): ['b4c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3', 'b7b6', 'b1c3', 'f8b4', 'a2a3', 'b4c3'): ['b2c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3', 'b7b6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3'): ['c8b7'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'd7d5'): ['c4d5'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'd1c2', 'd7d5', 'c4d5'): ['e6d5'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3'): ['b4c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3'): ['b2c3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3'): ['c7c5'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3', 'c7c5'): ['e2e3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3', 'c7c5', 'e2e3'): ['e8g8'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3', 'c7c5', 'e2e3', 'e8g8'): ['g1f3'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3', 'c7c5', 'e2e3', 'e8g8', 'g1f3'): ['b7b6'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3', 'c7c5', 'e2e3', 'e8g8', 'g1f3', 'b7b6'): ['f1e2'],
('d2d4', 'g8f6', 'c2c4', 'e7e6', 'b1c3', 'f8b4', 'a2a3', 'b4c3', 'b2c3', 'c7c5', 'e2e3', 'e8g8', 'g1f3', 'b7b6', 'f1e2'): ['c8a6'],
('d2d4', 'g8f6', 'c1f4'): ['d7d5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5'): ['e2e3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3'): ['c7c5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5'): ['g1f3'],
('e2e4',): ['c7c6'],
('e2e4', 'c7c6'): ['d2d4', 'g1f3'],
('e2e4', 'c7c6', 'd2d4'): ['d7d5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5'): ['e4d5', 'b1c3', 'f2f3', 'e4e5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5'): ['c6d5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5'): ['g1f3', 'c2c4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3'): ['b8c6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6'): ['f1e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2'): ['g8f6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6'): ['b1c3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6', 'b1c3'): ['c8f5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6', 'b1c3', 'c8f5'): ['e1g1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6', 'b1c3', 'c8f5', 'e1g1'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6', 'b1c3', 'c8f5', 'e1g1', 'e7e6'): ['c1f4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6', 'b1c3', 'c8f5', 'e1g1', 'e7e6', 'c1f4'): ['f8e7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6', 'b1c3', 'c8f5', 'e1g1', 'e7e6', 'c1f4', 'f8e7'): ['f1e1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'g1f3', 'b8c6', 'f1e2', 'g8f6', 'b1c3', 'c8f5', 'e1g1', 'e7e6', 'c1f4', 'f8e7', 'f1e1'): ['e8g8'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4'): ['g8f6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6'): ['b1c3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3'): ['f8e7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7'): ['f1e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7', 'f1e2'): ['e8g8', 'd5c4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7', 'f1e2', 'e8g8'): ['e1g1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7', 'f1e2', 'e8g8', 'e1g1'): ['b7b6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7', 'f1e2', 'd5c4'): ['e2c4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7', 'f1e2', 'd5c4', 'e2c4'): ['e8g8'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7', 'f1e2', 'd5c4', 'e2c4', 'e8g8'): ['e1g1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4d5', 'c6d5', 'c2c4', 'g8f6', 'g1f3', 'e7e6', 'b1c3', 'f8e7', 'f1e2', 'd5c4', 'e2c4', 'e8g8', 'e1g1'): ['b7b6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3'): ['d5e4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4'): ['f2f3', 'c3e4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'f2f3'): ['e4e3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'f2f3', 'e4e3'): ['c1e3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'f2f3', 'e4e3', 'c1e3'): ['g8f6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4'): ['g8f6', 'c8f5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6'): ['e4f6', 'e4g3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6'): ['e7f6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6'): ['c2c3', 'g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6', 'c2c3'): ['f8d6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6', 'c2c3', 'f8d6'): ['f1d3', 'g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6', 'c2c3', 'f8d6', 'f1d3'): ['e8g8'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6', 'c2c3', 'f8d6', 'g1f3'): ['e8g8'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6', 'g1f3'): ['f8d6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6', 'g1f3', 'f8d6'): ['f1d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4f6', 'e7f6', 'g1f3', 'f8d6', 'f1d3'): ['e8g8'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'g8f6', 'e4g3'): ['g7g6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5'): ['e4g3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3'): ['f5g6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6'): ['h2h4'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4'): ['h7h6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6'): ['f3e5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5'): ['g6h7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7'): ['f1d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3'): ['h7d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3', 'h7d3'): ['d1d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3', 'h7d3', 'd1d3'): ['b8d7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'g1f3', 'e7e6', 'f3e5', 'g6h7', 'f1d3', 'h7d3', 'd1d3', 'b8d7'): ['d3e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'f2f3'): ['g7g6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'f2f3', 'g7g6'): ['b1c3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'f2f3', 'g7g6', 'b1c3'): ['f8g7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'f2f3', 'g7g6', 'b1c3', 'f8g7'): ['c1e3'],
('e2e4', 'c7c6', 'g1f3'): ['d7d5'],
('e2e4', 'c7c6', 'g1f3', 'd7d5'): ['b1c3'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3'): ['d5e4'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4'): ['c3e4'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4'): ['c8f5'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5'): ['e4g3'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3'): ['f5g6'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6'): ['h2h4'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4'): ['h7h6'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6'): ['f3e5'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'f3e5'): ['d8d6'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'f3e5', 'd8d6'): ['e5g6'],
('e2e4', 'c7c6', 'g1f3', 'd7d5', 'b1c3', 'd5e4', 'c3e4', 'c8f5', 'e4g3', 'f5g6', 'h2h4', 'h7h6', 'f3e5', 'd8d6', 'e5g6'): ['d6g6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5'): ['c6c5', 'c8f5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5'): ['d4c5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3'): ['f8c5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5'): ['f1d3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3'): ['b8c6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6'): ['e1g1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1'): ['g8e7'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1', 'g8e7'): ['a2a3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1', 'g8e7', 'a2a3'): ['a7a5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c6c5', 'd4c5', 'e7e6', 'g1f3', 'f8c5', 'f1d3', 'b8c6', 'e1g1', 'g8e7', 'a2a3', 'a7a5'): ['d1e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5'): ['g1f3'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3'): ['e7e6'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6'): ['f1e2'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6', 'f1e2'): ['c6c5'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6', 'f1e2', 'c6c5'): ['e1g1'],
('e2e4', 'c7c6', 'd2d4', 'd7d5', 'e4e5', 'c8f5', 'g1f3', 'e7e6', 'f1e2', 'c6c5', 'e1g1'): ['b8c6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3'): ['d8b6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6'): ['b1c3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3'): ['a7a6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6'): ['d4c5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5'): ['b6c5'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5'): ['f1d3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3'): ['c8g4'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4'): ['h2h3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3'): ['g4f3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3'): ['d1f3'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3', 'd1f3'): ['e7e6'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3', 'd1f3', 'e7e6'): ['e1g1'],
('d2d4', 'g8f6', 'c1f4', 'd7d5', 'e2e3', 'c7c5', 'g1f3', 'd8b6', 'b1c3', 'a7a6', 'd4c5', 'b6c5', 'f1d3', 'c8g4', 'h2h3', 'g4f3', 'd1f3', 'e7e6', 'e1g1'): ['b8c6']}

    def add_opening(self, sequence, is_white_opening: bool):
        """
        Adds a sequence of moves to the opening book.
        Each prefix becomes a key mapped to possible next moves.
        Input: list of 4-character move strings like ["e2e4", "e7e5", "g1f3"]
        """

        book = self.white_book if is_white_opening else self.black_book

        for i in range(len(sequence)):
            prefix = tuple(sequence[:i])
            next_move = sequence[i]
            if prefix in book:
                if next_move not in book[prefix]:
                    book[prefix].append(next_move)
            else:
                book[prefix] = [next_move]

    def get_next_move(self, gs: GameState, randomize=True):
        """
        Given the current move log (list of Move objects) and the current board,
        returns the next Move object from the opening book.
        """
        # Convert move log into a tuple of strings like ("e2e4", "e7e5")

        book = self.white_book if gs.white_to_move else self.black_book

        history = tuple(move.get_chess_notation() for move in gs.move_log)
        options = book.get(history)

        if not options:
            return None  # No opening move found

        # Choose next move string, e.g., "g1f3"
        next_move_str = random.choice(options) if randomize else options[0]

        # Extract coordinates from notation
        start_sq_str = next_move_str[:2]
        end_sq_str = next_move_str[2:]

        # Convert from algebraic notation to internal row/column
        start_row = Move.ranks_to_rows[start_sq_str[1]]
        start_col = Move.files_to_columbs[start_sq_str[0]]
        end_row = Move.ranks_to_rows[end_sq_str[1]]
        end_col = Move.files_to_columbs[end_sq_str[0]]

        castling_move = (((start_row, start_col) == gs.white_king_location or (start_row, start_col) == gs.black_king_location)
                         and abs(start_col-end_col) == 2)

        # Construct and return a new Move object
        return Move((start_row, start_col), (end_row, end_col), gs.board, is_castle_move=castling_move)

    def contains(self, gs: GameState):
        """
        Check whether the move log is part of any stored opening.
        """
        book = self.white_book if gs.white_to_move else self.black_book
        history = tuple(move.get_chess_notation() for move in gs.move_log)
        return history in book


