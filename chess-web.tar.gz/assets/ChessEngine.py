"""
This class is responsible for storing all information for the current state of the game. Also responsible for
determining valid moves. It also has the move log.
"""
import random
from Parameters import Parameters


# ── Zobrist hashing tables (deterministic seed) ────────────────────────────
import random as _zr
_zr.seed(42)
_PIECE_LIST = ['wp','wR','wN','wB','wQ','wK','bp','bR','bN','bB','bQ','bK']
_PIECE_IDX  = {p: i for i, p in enumerate(_PIECE_LIST)}
_ZOB_PIECE  = [[_zr.getrandbits(64) for _ in range(64)] for _ in range(12)]
_ZOB_SIDE   = _zr.getrandbits(64)          # XOR in when black to move
_ZOB_CAST   = [_zr.getrandbits(64) for _ in range(4)]   # wks wqs bks bqs
_ZOB_EP     = [_zr.getrandbits(64) for _ in range(8)]   # indexed by file

class GameState():
    def __init__(self):
        # The board made by a 2D list
        self.white_to_move = True  # variable for if white to move (boolian) used to determine whose turn it is
        self.starting_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        self.move_log = []  # log of all moves in the game
        self.white_king_location = (7, 4)  # white king location
        self.black_king_location = (0, 4)  # black king location
        self.checkmate = False  # a boolean value for checkmate
        self.stalemate = False  # a boolean value for stalemate
        self.draw_by_repetition =  False # a boolean value for draw by repetition
        self.in_check = False  # a boolean value for player being in check
        self.pins = []  # a list of all pins in a position
        self.checks = []  # a list of all checks in a position
        self.en_passant_possible = ()  # where an anpassant value is possible, (row, columb)
        self.white_has_castled = False
        self.black_has_castled = False
        self.current_castling_rights = Castle_rights(True, True, True, True)  # the current casteling rights
        self.castle_rights_log = [Castle_rights(self.current_castling_rights.wks, self.current_castling_rights.wqs,
                                                self.current_castling_rights.bks, self.current_castling_rights.bqs)]  # a list of the castling rights

        self.board = self.set_up_board()  # function to set up starting board (from starting fen)

        # Zobrist hashing for repetition detection
        self.zobrist_hash = self._compute_hash()
        self.position_history = {self.zobrist_hash: 1}
        self.hash_log = []        # parallel to castle_rights_log, stores hash before each make_move

        # Incremental evaluation — avoids O(64) board scans on every AI eval call.
        # material_on_board is unsigned (both colors summed); pieces_on_board_score
        # and the PST scores are signed (white +, black -), matching score_board()'s
        # original from-scratch computation exactly.
        self.params = Parameters()
        self.material_on_board = 0
        self.pieces_on_board_score = 0
        self.early_game_position_score = 0
        self.end_game_position_score = 0
        self._init_eval_totals()

    def _compute_hash(self):
        """Recompute the full Zobrist hash from the current board state."""
        h = 0
        for r in range(8):
            for c in range(8):
                p = self.board[r][c]
                if p != "--":
                    h ^= _ZOB_PIECE[_PIECE_IDX[p]][r * 8 + c]
        if not self.white_to_move:
            h ^= _ZOB_SIDE
        cr = self.current_castling_rights
        if cr.wks: h ^= _ZOB_CAST[0]
        if cr.wqs: h ^= _ZOB_CAST[1]
        if cr.bks: h ^= _ZOB_CAST[2]
        if cr.bqs: h ^= _ZOB_CAST[3]
        if self.en_passant_possible:
            h ^= _ZOB_EP[self.en_passant_possible[1]]
        return h

    def _init_eval_totals(self):
        """One-time full-board scan to seed incremental eval totals (called only at __init__)."""
        p = self.params
        for r in range(8):
            for c in range(8):
                sq = self.board[r][c]
                if sq == "--":
                    continue
                color_sign = 1 if sq[0] == "w" else -1
                self.material_on_board += p.piece_score[sq[1]]
                self.pieces_on_board_score += color_sign * p.piece_score[sq[1]]
                self.early_game_position_score += color_sign * p.early_game_piece_position_scores[sq][r][c]
                self.end_game_position_score += color_sign * p.end_game_piece_position_scores[sq][r][c]

    def _apply_move_score(self, move, sign):
        """
        Add (sign=+1) or remove (sign=-1) a Move's effect on the running eval totals.
        Pure function of the Move object's own fields — safe to call identically from
        make_move (sign=+1) and undo_move (sign=-1) for perfectly symmetric bookkeeping.
        """
        p = self.params
        pm = move.piece_moved
        pm_sign = 1 if pm[0] == "w" else -1

        # piece_moved leaves its start square (PST only — same piece, no material change)
        self.early_game_position_score -= sign * pm_sign * p.early_game_piece_position_scores[pm][move.start_row][move.start_columb]
        self.end_game_position_score   -= sign * pm_sign * p.end_game_piece_position_scores[pm][move.start_row][move.start_columb]

        # piece arrives at destination square
        if move.is_pawn_promotion:
            promoted = pm[0] + (move.promotion_piece or "Q")
            mat_gain = p.piece_score[promoted[1]] - p.piece_score[pm[1]]
            self.material_on_board += sign * mat_gain
            self.pieces_on_board_score += sign * pm_sign * mat_gain
            self.early_game_position_score += sign * pm_sign * p.early_game_piece_position_scores[promoted][move.end_row][move.end_columb]
            self.end_game_position_score   += sign * pm_sign * p.end_game_piece_position_scores[promoted][move.end_row][move.end_columb]
        else:
            self.early_game_position_score += sign * pm_sign * p.early_game_piece_position_scores[pm][move.end_row][move.end_columb]
            self.end_game_position_score   += sign * pm_sign * p.end_game_piece_position_scores[pm][move.end_row][move.end_columb]

        # captured piece is removed from the board
        if move.piece_captured != "--":
            pc = move.piece_captured
            pc_sign = 1 if pc[0] == "w" else -1
            cap_row, cap_col = move.end_row, move.end_columb
            if move.is_enpassant_move:  # captured pawn sits beside the destination, not on it
                cap_row, cap_col = move.start_row, move.end_columb
            self.material_on_board -= sign * p.piece_score[pc[1]]
            self.pieces_on_board_score -= sign * pc_sign * p.piece_score[pc[1]]
            self.early_game_position_score -= sign * pc_sign * p.early_game_piece_position_scores[pc][cap_row][cap_col]
            self.end_game_position_score   -= sign * pc_sign * p.end_game_piece_position_scores[pc][cap_row][cap_col]

        # castling also moves the rook
        if move.is_castle_move:
            rook = pm[0] + "R"
            if move.end_columb - move.start_columb == 2:   # king side
                r_start_col, r_end_col = move.end_columb + 1, move.end_columb - 1
            else:                                            # queen side
                r_start_col, r_end_col = move.end_columb - 2, move.end_columb + 1
            self.early_game_position_score -= sign * pm_sign * p.early_game_piece_position_scores[rook][move.end_row][r_start_col]
            self.end_game_position_score   -= sign * pm_sign * p.end_game_piece_position_scores[rook][move.end_row][r_start_col]
            self.early_game_position_score += sign * pm_sign * p.early_game_piece_position_scores[rook][move.end_row][r_end_col]
            self.end_game_position_score   += sign * pm_sign * p.end_game_piece_position_scores[rook][move.end_row][r_end_col]

    """
    returns the starting board
    """
    def set_up_board(self):
        starting_board = self.fen_to_board(self.starting_fen)

        return starting_board

    def fen_to_board(self, fen):
        """
        Convert a FEN string to a 2D board array representation.

        Parameters:
        - fen: A string representing the board state in FEN.

        Returns:
        - A 2D list representing the chess board.
        """
        # Split the FEN string to get the piece placement
        fen_parts = fen.split()

        # decides whose turn to move
        if fen_parts[1] == "w":
            self.white_to_move = True
        else:
            self.white_to_move = False

        fen_castling_rights = fen_parts[2]

        castling_rights_map = {  # maps the fen string notation to current castling rights
            "K": "wks",
            "Q": "wqs",
            "k": "bks",
            "q": "bqs"
        }

        for key, attr in castling_rights_map.items():  # returns a tuple (key, attr)
            setattr(self.current_castling_rights, attr, key in fen_castling_rights)  # sets an attribute attr in Castle_rights if key is inside catling_rights


        piece_placement = fen_parts[0]

        # Create an empty 8x8 board
        board = [["--" for _ in range(8)] for _ in range(8)]

        # Map pieces to their notations
        piece_map = {
            'p': 'bp', 'r': 'bR', 'n': 'bN', 'b': 'bB', 'q': 'bQ', 'k': 'bK',  # Black pieces
            'P': 'wp', 'R': 'wR', 'N': 'wN', 'B': 'wB', 'Q': 'wQ', 'K': 'wK'  # White pieces
        }

        # Convert piece placement to the board array
        rows = piece_placement.split('/')
        for i, row in enumerate(rows):
            j = 0  # Column index
            for char in row:
                if char.isdigit():  # If the character is a number
                    j += int(char)  # Skip that many squares
                else:  # If it's a piece character
                    board[i][j] = piece_map[char]
                    if char == "k":
                        self.black_king_location = (i, j)
                    elif char == "K":
                        self.white_king_location = (i, j)
                    j += 1  # Move to the next column

        return board

    def board_to_fen(self, board):  # takes in a board position as a 2 dimentional array and returns a fen string
        pass

    def make_move(self, move):  # make move function, used to make a move on the board
        self.board[move.start_row][move.start_columb] = "--"
        self.board[move.end_row][move.end_columb] = move.piece_moved
        self.move_log.append(move)  # log the move
        self.white_to_move = not self.white_to_move  # other players turn
        # update king location if king moves
        if move.piece_moved == "wK":
            self.white_king_location = (move.end_row, move.end_columb)
        elif move.piece_moved == "bK":
            self.black_king_location = (move.end_row, move.end_columb)
        if move.piece_moved[1] == "p" and abs(move.start_row - move.end_row) == 2:
            self.en_passant_possible = ((move.start_row + move.end_row)//2, move.end_columb)
        else:
            self.en_passant_possible = ()
        if move.is_enpassant_move:
            self.board[move.start_row][move.end_columb] = "--"

        # pawn promotion
        if move.is_pawn_promotion:
            self.board[move.end_row][move.end_columb] = move.piece_moved[0] + (move.promotion_piece or "Q")

        # castle move
        if move.is_castle_move:
            if move.end_columb - move.start_columb == 2:  # a king side castle move
                self.board[move.end_row][move.end_columb-1] = self.board[move.end_row][move.end_columb+1] # copies rook to sq
                self.board[move.end_row][move.end_columb+1] = "--"

            else:  # queen side castle move
                self.board[move.end_row][move.end_columb + 1] = self.board[move.end_row][move.end_columb - 2]
                self.board[move.end_row][move.end_columb - 2] = "--"

            if self.white_to_move:
                self.white_has_castled = True
            else:
                self.black_has_castled = True


        #update castling rights
        self.update_castling_rights(move)
        self.castle_rights_log.append(Castle_rights(self.current_castling_rights.wks, self.current_castling_rights.wqs,
                                                self.current_castling_rights.bks, self.current_castling_rights.bqs))
        # Zobrist: save old hash, recompute new hash, record in history
        self.hash_log.append(self.zobrist_hash)
        self.zobrist_hash = self._compute_hash()
        self.position_history[self.zobrist_hash] = self.position_history.get(self.zobrist_hash, 0) + 1
        self._apply_move_score(move, 1)  # incremental eval update


    def undo_move(self):
        if len(self.move_log) != 0:
            # Zobrist: remove current position from history, restore previous hash
            self.position_history[self.zobrist_hash] = self.position_history.get(self.zobrist_hash, 1) - 1
            self.zobrist_hash = self.hash_log.pop()
            move = self.move_log.pop()
            self._apply_move_score(move, -1)  # incremental eval update (reverse)
            self.board[move.start_row][move.start_columb] = move.piece_moved  # put piece on starting squere
            self.board[move.end_row][move.end_columb] = move.piece_captured  # put back piece captured
            self.white_to_move = not self.white_to_move  # switch turns back
            if move.piece_moved == "wK":  # update king location
                self.white_king_location = (move.start_row, move.start_columb)
            elif move.piece_moved == "bK":
                self.black_king_location = (move.start_row, move.start_columb)
            # undo en passant
            if move.is_enpassant_move:
                self.board[move.end_row][move.end_columb] = "--"  # remove the pawn that was put back incorrectly
                self.board[move.start_row][move.end_columb] = move.piece_captured  # put back captured pawn on correct squere
                self.en_passant_possible = (move.end_row, move.end_columb)  # make en passant possible
            if move.piece_moved[1] == "p" and abs(move.start_row - move.end_row) == 2:  # no en passant possible, changed move.end_columb to move.end_row but no diff (seems useless)
                self.en_passant_possible = ()

            #undo castling rights
            self.castle_rights_log.pop() # det rid of old castle right
            cr = self.castle_rights_log[-1]
            self.current_castling_rights = Castle_rights(cr.wks, cr.wqs, cr.bks, cr.bqs)
            #undo the castle move
            if move.is_castle_move:
                if move.end_columb - move.start_columb == 2:  # king side
                    self.board[move.end_row][move.end_columb + 1] = self.board[move.end_row][move.end_columb - 1]  # copies rook to sq
                    self.board[move.end_row][move.end_columb - 1] = "--"
                else:
                    self.board[move.end_row][move.end_columb - 2] = self.board[move.end_row][move.end_columb + 1]  # copies rook to sq
                    self.board[move.end_row][move.end_columb + 1] = "--"

                if self.white_to_move:
                    self.white_has_castled = False
                else:
                    self.black_has_castled = False

            self.checkmate = False
            self.stalemate = False
            self.draw_by_repetition = False



    """
    Returns if squere is under attack
    """

    def squere_under_attack(self, r, c):
        ally_color = "w" if self.white_to_move else "b"
        enemy_color = "w" if ally_color == "b" else "b"
        directions = ((-1, 0), (0, -1), (1, 0), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1))
        for j in range(len(directions)):
            d = directions[j]
            for i in range(1, 8):  # max 7 squeres to king
                end_row = r + d[0] * i
                end_columb = c + d[1] * i
                if 0 <= end_row < 8 and 0 <= end_columb < 8:
                    end_piece = self.board[end_row][end_columb]
                    if end_piece[0] == ally_color:
                        break
                    elif end_piece[0] == enemy_color:
                        type = end_piece[1]
                        # 5 possibilities
                        # 1, horisontal and vertikly away from king and is rook
                        # 2, diagnaly and bishop
                        # 3, 1 squere away diagnaly and is pawn
                        # 4 any direction and is queen
                        # 5, any direction 1 squere away and is king (avoid king next to king)
                        if (0 <= j <= 3 and type == "R") or \
                                (4 <= j <= 7 and type == "B") or \
                                (i == 1 and type == "p" and ((enemy_color == "w" and 6 <= j <= 7) or (
                                        enemy_color == "b" and 4 <= j <= 5))) or \
                                (type == "Q") or (i == 1 and type == "K"):
                            return True
                        else:
                            break  # if the first enemy piece doesn't attack a square it blocks and we stop searching further

                else:
                    break
        knight_moves = ((-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1))
        for m in knight_moves:
            end_row = r + m[0]
            end_columb = c + m[1]
            if 0 <= end_row < 8 and 0 <= end_columb < 8:
                end_piece = self.board[end_row][end_columb]
                if end_piece[0] == enemy_color and end_piece[1] == "N":
                    return True

        return False
    """
    update castling rights when rock or king moves given a move
    """
    def update_castling_rights(self, move):
        if move.piece_moved == "wK":
            self.current_castling_rights.wks = False
            self.current_castling_rights.wqs = False
        elif move.piece_moved == "bK":
            self.current_castling_rights.bks = False
            self.current_castling_rights.bqs = False
        elif move.piece_moved == "wR":
            if move.start_row == 7:
                if move.start_columb == 0:
                    self.current_castling_rights.wqs = False
                elif move.start_columb == 7:
                    self.current_castling_rights.wks = False
        elif move.piece_moved == "bR":
            if move.start_row == 0:
                if move.start_columb == 0:
                    self.current_castling_rights.bqs = False
                elif move.start_columb == 7:
                    self.current_castling_rights.bks = False
        # if captured rook
        if move.piece_captured == "wR":
            if move.end_row == 7:
                if move.end_columb == 7:
                    self.current_castling_rights.wks = False
                elif move.end_columb == 0:
                    self.current_castling_rights.wqs = False
        elif move.piece_captured == "bR":
            if move.end_row == 0:
                if move.end_columb == 7:
                    self.current_castling_rights.bks = False
                elif move.end_columb == 0:
                    self.current_castling_rights.bqs = False


    def get_valid_moves(self):
        moves = []
        self.in_check, self.pins, self.checks = self.check_for_pins_and_checks()

        if self.white_to_move:
            king_row = self.white_king_location[0]
            king_columb = self.white_king_location[1]
        else:
            king_row = self.black_king_location[0]
            king_columb = self.black_king_location[1]
        if self.in_check:
            if len(self.checks) == 1:  # only one check, block, move or capture
                moves = self.get_all_possible_moves()
                check = self.checks[0]
                check_row = check[0]
                check_columb = check[1]
                piece_checking = self.board[check_row][check_columb]
                valid_squeres = []
                if piece_checking[1] == "N":
                    valid_squeres = [(check_row, check_columb)]
                else:
                    for i in range(1, 8):
                        valid_squere = (king_row + check[2] * i, king_columb + check[3] * i)  # [2] and [3] are king direktions
                        valid_squeres.append(valid_squere)
                        if valid_squere[0] == check_row and valid_squere[1] == check_columb:
                            break
                # get rid of moves that don't block or move king
                for i in range(len(moves) - 1, -1, -1):  # remove backwords (avoids bugs)
                    if moves[i].piece_moved[1] != "K":  # if king dosen't move, piece must capture or block
                        if not (moves[i].end_row, moves[i].end_columb) in valid_squeres:  # not a block or capture
                            moves.remove(moves[i])
            else:  # dubble check = king has to move
                self.get_king_moves(king_row, king_columb, moves)
        else:
            moves = self.get_all_possible_moves()

        # use zobrist hashing later
        if self.check_for_repetition():
            self.draw_by_repetition = True


        if len(moves) == 0:
            if self.in_check:
                self.checkmate = True
            else:
                self.stalemate = True
        return moves

    """
    returns True if draw by repetition else False
    """
    def check_for_repetition(self):
        # Threefold repetition via Zobrist hash
        if self.position_history.get(self.zobrist_hash, 0) >= 3:
            return True

        # 50-move rule: 100 consecutive plies with no pawn move or capture
        if len(self.move_log) >= 100:
            consecutive = 0
            for move in reversed(self.move_log[-100:]):
                if move.piece_captured != "--" or move.piece_moved[1] == "p":
                    break
                consecutive += 1
            if consecutive >= 100:
                return True

        return False

    def get_all_possible_moves(self):
        moves = []
        for r in range(len(self.board)):
            for c in range(len(self.board[r])):
                turn = self.board[r][c][0]
                if (turn == "w" and self.white_to_move) or (turn == "b" and not self.white_to_move):
                    piece = self.board[r][c][1]

                    if piece == "p":
                        self.get_pawn_moves(r, c, moves)

                    elif piece == "R":
                        self.get_rook_moves(r, c, moves)

                    elif piece == "N":
                        self.get_knight_moves(r, c, moves)
                    elif piece == "K":
                        self.get_king_moves(r, c, moves)
                    elif piece == "B":
                        self.get_bishop_moves(r, c, moves)
                    elif piece == "Q":
                        self.get_queen_moves(r, c, moves)
        return moves

    def check_for_pins_and_checks(self):
        pins = []  # squere where pined piece is and direction from
        checks = []  # enemy piece giving the check
        in_check = False
        if self.white_to_move:
            enemy_color = "b"
            ally_color = "w"
            start_row = self.white_king_location[0]
            start_columb = self.white_king_location[1]
        else:
            enemy_color = "w"
            ally_color = "b"
            start_row = self.black_king_location[0]
            start_columb = self.black_king_location[1]
        # start from king and chack pins and checks outword from king
        directions = ((-1, 0), (0, -1), (1, 0), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1))
        for j in range(len(directions)):
            d = directions[j]
            possible_pin = ()  # reset
            for i in range(1, 8):  # max 7 squeres to king
                end_row = start_row + d[0] * i
                end_columb = start_columb + d[1] * i
                if 0 <= end_row < 8 and 0 <= end_columb < 8:
                    end_piece = self.board[end_row][end_columb]
                    if end_piece[0] == ally_color and end_piece[1] != "K":
                        if possible_pin == ():  # first allied piece could be pinned
                            possible_pin = (end_row, end_columb, d[0], d[1])
                        else:  # second allied piece (no check or pin possible)
                            break
                    elif end_piece[0] == enemy_color:
                        type = end_piece[1]
                        # 5 possibilities
                        # 1, horisontal and vertikly away from king and is rook
                        # 2, diagnaly and bishop
                        # 3, 1 squere away diagnaly and is pawn
                        # 4 any direction and is queen
                        # 5, any direction 1 squere away and is king (avoid king next to king)
                        if (0 <= j <= 3 and type == "R") or \
                                (4 <= j <= 7 and type == "B") or \
                                (i == 1 and type == "p" and ((enemy_color == "w" and 6 <= j <= 7) or (enemy_color == "b" and 4 <= j <= 5))) or \
                                (type == "Q") or (i == 1 and type == "K"):
                            if possible_pin == ():
                                in_check = True
                                checks.append((end_row, end_columb, d[0], d[1]))
                                break
                            else:  # piece blocking, it's a pin
                                pins.append(possible_pin)
                                break
                        else:  # enemy piece not checking
                            break
                else:
                    break
        # check for knight checks
        knight_moves = ((-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1))
        for m in knight_moves:
            end_row = start_row + m[0]
            end_columb = start_columb + m[1]
            if 0 <= end_row < 8 and 0 <= end_columb < 8:
                end_piece = self.board[end_row][end_columb]
                if end_piece[0] == enemy_color and end_piece[1] == "N":
                    in_check = True
                    checks.append((end_row, end_columb, m[0], m[1]))
        return in_check, pins, checks

    # get moves for piece in row, columb
    def get_pawn_moves(self, r, c, moves):
        piece_pinned = False
        pin_direction = ()
        for i in range(len(self.pins) - 1, -1, -1):
            if self.pins[i][0] == r and self.pins[i][1] == c:
                piece_pinned = True
                pin_direction = (self.pins[i][2], self.pins[i][3])
                self.pins.remove(self.pins[i])
                break

        if self.white_to_move:
            move_amount = -1
            start_row = 6
            enemy_color = "b"
        else:
            move_amount = 1
            start_row = 1
            enemy_color = "w"

        _PROMO_PIECES = ["Q", "R", "B", "N"]

        def _add_move(start, end, **kw):
            # Append move; if destination is a promotion square, add all 4 piece choices
            dest_row = end[0]
            if (dest_row == 0 or dest_row == 7) and not kw.get("is_enpassant_move"):
                for pp in _PROMO_PIECES:
                    moves.append(Move(start, end, self.board, promotion_piece=pp, **kw))
            else:
                moves.append(Move(start, end, self.board, **kw))

        if self.board[r + move_amount][c] == "--":  # if square in front is empty
            if not piece_pinned or pin_direction == (move_amount, 0) or pin_direction == (-move_amount, 0):
                _add_move((r, c), (r + move_amount, c))
                if r == start_row and self.board[r + move_amount*2][c] == "--":
                    _add_move((r, c), (r + move_amount*2, c))

        if c - 1 >= 0:  # capture to the left
            if not piece_pinned or pin_direction == (move_amount, -1):
                if self.board[r + move_amount][c - 1][0] == enemy_color:
                    _add_move((r, c), (r + move_amount, c - 1))
                if (r + move_amount, c - 1) == self.en_passant_possible:
                    moves.append(Move((r, c), (r + move_amount, c-1), self.board, is_enpassant_move=True))

        if c + 1 <= 7:  # capture to the right
            if not piece_pinned or pin_direction == (move_amount, 1):
                if self.board[r + move_amount][c + 1][0] == enemy_color:
                    _add_move((r, c), (r + move_amount, c + 1))
                if (r + move_amount, c + 1) == self.en_passant_possible:
                    moves.append(Move((r, c), (r + move_amount, c + 1), self.board, is_enpassant_move=True))

    def get_king_moves(self, r, c, moves):
        row_moves = (-1, -1, -1, 0, 0, 1, 1, 1)
        columb_moves = (-1, 0, 1, -1, 1, -1, 0, 1)
        ally_color = "w" if self.white_to_move else "b"
        for i in range(8):
            end_row = r + row_moves[i]
            end_columb = c + columb_moves[i]
            if 0 <= end_row < 8 and 0 <= end_columb < 8:
                end_piece = self.board[end_row][end_columb]
                if end_piece[0] != ally_color:
                    if ally_color == "w":
                        self.white_king_location = (end_row, end_columb)
                    else:
                        self.black_king_location = (end_row, end_columb)
                    in_check, pins, checks = self.check_for_pins_and_checks()  # check if king move results in a possible cature of king
                    if not in_check:  # if not the move is leagle
                        moves.append(Move((r, c), (end_row, end_columb), self.board))
                    if ally_color == "w":
                        self.white_king_location = (r, c)
                    else:
                        self.black_king_location = (r, c)
        self.get_castle_moves(r, c, moves)


    """
    generate all valid castling moves
    """

    def get_castle_moves(self, r, c, moves):
        ally_color = "w" if self.white_to_move else "b"
        in_check = self.squere_under_attack(r, c)
        if in_check:
            return  # can't castle when in check
        if (self.white_to_move and self.current_castling_rights.wks) or (not self.white_to_move and self.current_castling_rights.bks):
            self.get_king_side_castle_moves(r, c, moves)
        if (self.white_to_move and self.current_castling_rights.wqs) or (not self.white_to_move and self.current_castling_rights.bqs):
            self.get_queen_side_castle_moves(r, c, moves)

    def get_king_side_castle_moves(self, r, c, moves):

        if self.board[r][c+1] == "--" and self.board[r][c+2] == "--":
            if not self.squere_under_attack(r, c+1) and not self.squere_under_attack(r, c+2):
                moves.append(Move((r, c), (r, c + 2), self.board, is_castle_move=True))

    def get_queen_side_castle_moves(self, r, c, moves):
        if self.board[r][c-1] == "--" and self.board[r][c-2] == "--" and self.board[r][c-3] == "--":
            if not self.squere_under_attack(r, c-1) and not self.squere_under_attack(r, c-2):
                moves.append(Move((r, c), (r, c-2), self.board, is_castle_move=True))


    def get_rook_moves(self, r, c, moves):
        piece_pinned = False
        pin_direction = ()
        for i in range(len(self.pins) - 1, -1, -1):
            if self.pins[i][0] == r and self.pins[i][1] == c:
                piece_pinned = True
                pin_direction = (self.pins[i][2], self.pins[i][3])
                if self.board[r][c][1] != "Q":  # if the piece is the queen, it should not remove pin becaouse it is bissop + rook move
                    self.pins.remove(self.pins[i])
                break
        directions = [(-1, 0), (0, -1), (1, 0), (0, 1)]  # right, down, left, up

        for direction in directions:
            for i in range(1, 8):  # 1 to 7 squeres the rook can move
                new_row, new_col = r + direction[0] * i, c + direction[1] * i  # i squeres in direction

                if 0 <= new_row < 8 and 0 <= new_col < 8:  # move on chess board
                    if not piece_pinned or pin_direction == direction or pin_direction == (-direction[0], -direction[1]):
                        piece_at_squere = self.board[new_row][new_col]

                        if piece_at_squere == "--":  # empty squere
                            moves.append(Move((r, c), (new_row, new_col), self.board))

                        elif piece_at_squere[0] != self.board[r][c][0]:  # if enemy piece
                            moves.append(Move((r, c), (new_row, new_col), self.board))
                            break
                        else:  # if friendly piece
                            break
                else:
                    break

    def get_bishop_moves(self, r, c, moves):
        piece_pinned = False
        pin_direction = ()
        for i in range(len(self.pins) - 1, -1, -1):
            if self.pins[i][0] == r and self.pins[i][1] == c:
                piece_pinned = True
                pin_direction = (self.pins[i][2], self.pins[i][3])
                self.pins.remove(self.pins[i])
                break

        directions = [(1, 1), (1, -1), (-1, -1), (-1, 1)]  # up right, up left, down left, down right
        for direction in directions:
            for i in range(1, 8):  # 1 to 7 squeres the bishop can move
                new_row, new_columb = r + direction[0] * i, c + direction[1] * i

                if 0 <= new_row <= 7 and 0 <= new_columb <= 7:
                    if not piece_pinned or pin_direction == direction or pin_direction == (-direction[0], -direction[1]):
                        piece_at_squere = self.board[new_row][new_columb]

                        if piece_at_squere == "--":
                            moves.append(Move((r, c), (new_row, new_columb), self.board))

                        elif piece_at_squere[0] != self.board[r][c][0]:
                            moves.append(Move((r, c), (new_row, new_columb), self.board))
                            break
                        else:  # if friendly piece
                            break
                else:
                    break

    def get_queen_moves(self, r, c, moves):
        self.get_rook_moves(r, c, moves)
        self.get_bishop_moves(r, c, moves)

    def get_knight_moves(self, r, c, moves):
        piece_pinned = False
        pin_direction = ()
        for i in range(len(self.pins) - 1, -1, -1):
            if self.pins[i][0] == r and self.pins[i][1] == c:
                piece_pinned = True
                self.pins.remove(self.pins[i])
                break

        knight_moves = [(2, 1), (1, 2), (-1, 2), (-2, 1), (-2, -1), (-1, -2), (1, -2), (2, -1)]
        for move in knight_moves:
            new_row, new_columb = r + move[0], c + move[1]

            if 0 <= new_row <= 7 and 0 <= new_columb <= 7:
                if not piece_pinned:
                    piece_at_squere = self.board[new_row][new_columb]

                    if piece_at_squere == "--" or piece_at_squere[0] != self.board[r][c][0]:
                        moves.append(Move((r, c), (new_row, new_columb), self.board))
class Castle_rights:
    def __init__(self, wks, wqs, bks, bqs):
        self.wks = wks
        self.wqs = wqs
        self.bks = bks
        self.bqs = bqs

class Move():
    ranks_to_rows = {"1": 7, "2": 6, "3": 5, "4": 4,
                     "5": 3, "6": 2, "7": 1, "8": 0}
    rows_to_ranks = {v: k for k, v in ranks_to_rows.items()}
    files_to_columbs = {"a": 0, "b": 1, "c": 2, "d": 3,
                        "e": 4, "f": 5, "g": 6, "h": 7}
    columbs_to_files = {v: k for k, v in files_to_columbs.items()}


    def __init__(self, start_sq, end_sq, board, is_enpassant_move=False, is_castle_move=False, promotion_piece="Q"):
        self.start_row = start_sq[0]
        self.start_columb = start_sq[1]
        self.end_row = end_sq[0]
        self.end_columb = end_sq[1]
        self.piece_moved = board[start_sq[0]][start_sq[1]]
        self.piece_captured = board[end_sq[0]][end_sq[1]]
        # pawn promotion
        self.is_pawn_promotion = (self.piece_moved == "wp" and self.end_row == 0) or (self.piece_moved == "bp" and self.end_row == 7)
        self.promotion_piece = promotion_piece if self.is_pawn_promotion else None
        # enpassant move
        self.is_enpassant_move = is_enpassant_move
        if is_enpassant_move:
            self.piece_captured = "bp" if self.piece_moved == "wp" else "wp"  # enpassant captures opposite colored pawn
        # castle move
        self.is_castle_move = is_castle_move

        # move_id encodes start/end squares + promotion piece (0=none,1=Q,2=R,3=B,4=N)
        promo_code = {"Q": 1, "R": 2, "B": 3, "N": 4}.get(promotion_piece, 0) if self.is_pawn_promotion else 0
        self.move_id = (self.start_row * 100000 + self.start_columb * 10000
                        + self.end_row * 1000 + self.end_columb * 100 + promo_code)
    """overriding the equals method"""

    def __eq__(self, other):
        if isinstance(other, Move):
            return self.move_id == other.move_id
        elif isinstance(other, int):
            return self.move_id == other  # Compare with string representation (e.g., "e2e4")
        elif isinstance(other, str):
            return str(self.move_id) == other
        return False

    def get_chess_notation(self):
        # later on add proper chess notation
        return self.get_rank_file(self.start_row, self.start_columb) + self.get_rank_file(self.end_row, self.end_columb)

    def get_rank_file(self, r, c):
        return self.columbs_to_files[c] + self.rows_to_ranks[r]

