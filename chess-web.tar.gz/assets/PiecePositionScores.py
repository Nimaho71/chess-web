"""
Python file for storing piece position scores of the pieces (Piece square tables).

only pawns and king currently have unique PST for endgame (different from early game)
"""

early_game_white_knight_scores = [[-40, -30, -20, -20, -20, -20, -30, -40],
                       [-30, -10, 0, 0, 0, 0, -10, -30],
                       [-20, 0, 10, 15, 15, 10, 0, -20],
                       [-20, 5, 15, 20, 20, 15, 5, -20],
                       [-20, 0, 15, 20, 20, 15, 0, -20],
                       [-20, 5, 10, 15, 15, 10, 5, -20],
                       [-30, -10, 0, 5, 5, 0, -10, -30],
                       [-40, -30, -20, -20, -20, -20, -30, -40]]  # white knight piece squere table

early_game_black_knight_scores = early_game_white_knight_scores[::-1]  # black knight piece squere table (mirror of white)

end_game_white_knight_scores = [[-40, -30, -20, -20, -20, -20, -30, -40],
                       [-30, -10, 0, 0, 0, 0, -10, -30],
                       [-20, 0, 10, 15, 15, 10, 0, -20],
                       [-20, 5, 15, 20, 20, 15, 5, -20],
                       [-20, 0, 15, 20, 20, 15, 0, -20],
                       [-20, 5, 10, 15, 15, 10, 5, -20],
                       [-30, -10, 0, 5, 5, 0, -10, -30],
                       [-40, -30, -20, -20, -20, -20, -30, -40]]  # white knight piece squere table

end_game_black_knight_scores = end_game_white_knight_scores[::-1]

early_game_white_queen_scores = [[-20, -10, 0, 0, 0, 0, -10, -20],
                 [-10, 0, 5, 5, 5, 5, 0, -10],
                 [0, 5, 10, 10, 10, 10, 5, 0],
                 [0, 5, 10, 15, 15, 10, 5, 0],
                 [0, 5, 10, 15, 15, 10, 5, 0],
                 [0, 5, 10, 10, 10, 10, 5, 0],
                 [-10, 0, 5, 5, 5, 5, 0, -10],
                 [-20, -10, 0, 0, 0, 0, -10, -20]]  # white queen piece squere table

early_game_black_queen_scores = early_game_white_queen_scores[::-1]  # white_queen_scores flipped

end_game_white_queen_scores = [[-20, -10, 0, 0, 0, 0, -10, -20],
                 [-10, 0, 5, 5, 5, 5, 0, -10],
                 [0, 5, 10, 10, 10, 10, 5, 0],
                 [0, 5, 10, 15, 15, 10, 5, 0],
                 [0, 5, 10, 15, 15, 10, 5, 0],
                 [0, 5, 10, 10, 10, 10, 5, 0],
                 [-10, 0, 5, 5, 5, 5, 0, -10],
                 [-20, -10, 0, 0, 0, 0, -10, -20]]  # white queen piece squere table

end_game_black_queen_scores = end_game_white_queen_scores[::-1]  # white_queen_scores flipped

early_game_white_king_scores = [[-10, -15, -15, -20, -20, -15, -15, -10],
                     [-10, -15, -15, -20, -20, -15, -15, -10],
                     [-10, -15, -15, -20, -20, -15, -15, -10],
                     [-10, -15, -15, -20, -20, -15, -15, -10],
                     [-5, -10, -10, -15, -15, -10, -10, -5],
                     [0, -5, -5, -5, -5, -5, -5, 0],
                     [5, 5, 0, 0, 0, 0, 5, 5],
                     [15, 25, 10, 5, 5, 10, 25, 15]]  # white king piece square table

early_game_black_king_scores = early_game_white_king_scores[::-1]

end_game_white_king_scores = [[-20, -10, -10, -10, -10, -10, -10, -20],
                       [-5, 0, 5, 5, 5, 5, 0, -5],
                       [-10, -5, 20, 30, 30, 20, -5, -10],
                       [-15, -10, 35, 45, 45, 35, -10, -15],
                       [-20, -15, 30, 40, 40, 30, -15, -20],
                       [-25, -20, 20, 25, 25, 20, -20, -25],
                       [-30, -25, 0, 0, 0, 0, -25, -30],
                       [-50, -30, -30, -30, -30, -30, -30, -50]]

end_game_black_king_scores = end_game_white_king_scores[::-1]

early_game_white_pawn_scores = [[0, 0, 0, 0, 0, 0, 0, 0],
                     [50, 50, 50, 50, 50, 50, 50, 50],
                     [10, 10, 20, 35, 35, 20, 10, 10],
                     [5, 5, 10, 30, 30, 10, 5, 5],
                     [4, 0, 0, 23, 23, 0, 0, 4],
                     [6, -5, 10, 0, 0, -10, -5, 6],
                     [5, 10, 10, -20, -20, 10, 10, 5],
                     [0, 0, 0, 0, 0, 0, 0, 0]]  # white pawn piece square table

early_game_black_pawn_scores = early_game_white_pawn_scores[::-1]  # black pawn piece square table

end_game_white_pawn_scores = [[0, 0, 0, 0, 0, 0, 0, 0],
                     [90, 90, 90, 90, 90, 90, 90, 90],
                     [55, 55, 55, 55, 55, 55, 55, 55],
                     [32, 32, 32, 32, 32, 32, 32, 32],
                     [21, 21, 21, 21, 21, 21, 21, 21],
                     [10, 10, 10, 10, 10, 10, 10, 10],
                     [10, 10, 10, 10, 10, 10, 10, 10],
                     [0, 0, 0, 0, 0, 0, 0, 0]]

end_game_black_pawn_scores = end_game_white_pawn_scores[::-1]  # end_game_white_pawn_scores flipped

early_game_white_bishop_scores = [[-20, -10, -10, -10, -10, -10, -10, -20],
                       [-5, 0, 0, 0, 0, 0, 0, -5],
                       [-10, 0, 0, 5, 5, 0, 0, -10],
                       [-10, 5, 5, 10, 10, 5, 5, -10],
                       [-10, 0, 11, 15, 15, 11, 0, -10],
                       [-5, 10, 12, 10, 10, 12, 10, -5],
                       [-5, 10, 0, 0, 0, 0, 10, -5],
                       [0, -10, -10, 10, -10, -10, -10, 0]]  # white bishop piece square table

early_game_black_bishop_scores = early_game_white_bishop_scores[::-1]  # white bishop piece square table flipped

end_game_white_bishop_scores = [[-20, -10, -10, -10, -10, -10, -10, -20],
                       [-5, 0, 0, 0, 0, 0, 0, -5],
                       [-10, 0, 0, 5, 5, 0, 0, -10],
                       [-10, 5, 5, 10, 10, 5, 5, -10],
                       [-10, 0, 11, 15, 15, 11, 0, -10],
                       [-5, 10, 12, 10, 10, 12, 10, -5],
                       [-5, 10, 0, 0, 0, 0, 10, -5],
                       [0, -10, -10, 10, -10, -10, -10, 0]]  # white bishop piece square table

end_game_black_bishop_scores = end_game_white_bishop_scores[::-1]  # white bishop piece square table flipped

early_game_white_rook_scores = [[0, 0, 0, 0, 0, 0, 0, 0],
                     [12, 15, 15, 15, 15, 15, 15, 12],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [0, 0, 0, 10, 10, 0, 0, 0]]  # white rook piece square table

early_game_black_rook_scores = early_game_white_rook_scores[::-1]

end_game_white_rook_scores = [[0, 0, 0, 0, 0, 0, 0, 0],
                     [12, 15, 15, 15, 15, 15, 15, 12],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [-5, 0, 0, 0, 0, 0, 0, -5],
                     [0, 0, 0, 10, 10, 0, 0, 0]]  # white rook piece square table

end_game_black_rook_scores = end_game_white_rook_scores[::-1]