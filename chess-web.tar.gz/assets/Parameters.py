import random
import PiecePositionScores as PST

class Parameters:
    """Holds the static chess parameters the chess ai uses."""
    def __init__(self):
        self.piece_score = {"K": 0, "Q": 1000, "R": 500, "B": 330, "N": 300, "p": 100}

        self.early_game_piece_position_scores = {
            "wN": PST.early_game_white_knight_scores, "bN": PST.early_game_black_knight_scores, "wQ": PST.early_game_white_queen_scores,
            "bQ": PST.early_game_black_queen_scores, "wK": PST.early_game_white_king_scores, "bK": PST.early_game_black_king_scores,
            "wp": PST.early_game_white_pawn_scores, "bp": PST.early_game_black_pawn_scores, "wB": PST.early_game_white_bishop_scores,
             "bB": PST.early_game_black_bishop_scores, "wR": PST.early_game_white_rook_scores, "bR": PST.early_game_black_rook_scores
        }  # maps pieces to their early game piece square tables

        self.end_game_piece_position_scores = {
            "wN": PST.end_game_white_knight_scores, "bN": PST.end_game_black_knight_scores, "wQ": PST.end_game_white_queen_scores,
            "bQ": PST.end_game_black_queen_scores, "wK": PST.end_game_white_king_scores, "bK": PST.end_game_black_king_scores,
            "wp": PST.end_game_white_pawn_scores, "bp": PST.end_game_black_pawn_scores, "wB": PST.end_game_white_bishop_scores,
            "bB": PST.end_game_black_bishop_scores, "wR": PST.end_game_white_rook_scores, "bR": PST.end_game_black_rook_scores
        }  # maps pieces to their end game piece square tables

        self.early_game_piece_position_names = {
            "wN": "early_game_white_knight_scores", "bN": "early_game_black_knight_scores", "wQ": "early_game_white_queen_scores",
            "bQ": "early_game_black_queen_scores", "wK": "early_game_white_king_scores", "bK": "early_game_black_king_scores",
            "wp": "early_game_white_pawn_scores", "bp": "early_game_black_pawn_scores", "wB": "early_game_white_bishop_scores",
            "bB": "early_game_black_bishop_scores", "wR": "early_game_white_rook_scores", "bR": "early_game_black_rook_scores"
        }  # maps pieces to their early game piece square tables

        self.end_game_piece_position_names = {
            "wN": "end_game_white_knight_scores", "bN": "end_game_black_knight_scores", "wQ": "end_game_white_queen_scores",
            "bQ": "end_game_black_queen_scores", "wK": "end_game_white_king_scores", "bK": "end_game_black_king_scores",
            "wp": "end_game_white_pawn_scores", "bp": "end_game_black_pawn_scores", "wB": "end_game_white_bishop_scores",
            "bB": "end_game_black_bishop_scores", "wR": "end_game_white_rook_scores", "bR": "end_game_black_rook_scores"
        }  # maps pieces to their object names

    def __repr__(self):
        return self.print()

    def print(self):
        rounded_piece_scores = {}
        for piece, value in self.piece_score.items():
            rounded_piece_scores[piece] = round(value)

        print(f"self.piece_score={rounded_piece_scores}")

        for piece, table in self.early_game_piece_position_scores.items():
            print("")
            for i, row in enumerate(table):
                rounded_row = [round(value) for value in row]  # round values to integers (centi-pawns)
                if i == 0:
                    print(f"{self.early_game_piece_position_names[piece]} = [{rounded_row},")
                elif i == 7:
                    print(f"{rounded_row}]  # {self.early_game_piece_position_names[piece].replace("_", " ")}")
                else:
                    print(f"{rounded_row},")

        for piece, table in self.end_game_piece_position_scores.items():
            print("")
            for i, row in enumerate(table):
                rounded_row = [round(value) for value in row]  # round values to integers (centi-pawns)
                if i == 0:
                    print(f"{self.end_game_piece_position_names[piece]} = [{rounded_row},")
                elif i == 7:
                    print(f"{rounded_row}]  # {self.end_game_piece_position_names[piece].replace("_", " ")}")
                else:
                    print(f"{rounded_row},")

        return ""


